import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Users, 
  BookOpen,
  Check, 
  BookCopy, 
  User, 
  UserCog, 
  CreditCard, 
  FileText, 
  Settings, 
  LogOut 
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface SidebarProps {
  role?: string;
  isOpen: boolean;
  onClose: () => void;
}

interface SidebarLink {
  title: string;
  href: string;
  icon: React.ReactNode;
  roles: string[];
}

export default function Sidebar({ role, isOpen, onClose }: SidebarProps) {
  const [location, setLocation] = useLocation();
  const { logout } = useAuth();

  // Close sidebar when changing location on mobile
  useEffect(() => {
    if (isOpen) {
      onClose();
    }
  }, [location]);

  const handleLogout = async () => {
    await logout();
    setLocation("/login");
  };

  // Filter links based on user role
  const canView = (linkRoles: string[]) => {
    if (!role) return false;
    if (linkRoles.includes('all')) return true;
    if (role === 'super_admin') return true;
    return linkRoles.includes(role);
  };

  const links: { section: string, items: SidebarLink[] }[] = [
    {
      section: "Main",
      items: [
        {
          title: "Dashboard",
          href: "/",
          icon: <Home className="h-5 w-5" />,
          roles: ["all"],
        },
      ],
    },
    {
      section: "Student Management",
      items: [
        {
          title: "All Students",
          href: "/students/all",
          icon: <Users className="h-5 w-5" />,
          roles: ["admin", "super_admin"],
        },
        {
          title: "Current Students",
          href: "/students/current",
          icon: <BookOpen className="h-5 w-5" />,
          roles: ["admin", "super_admin", "instructor"],
        },
        {
          title: "Concluded Students",
          href: "/students/concluded",
          icon: <Check className="h-5 w-5" />,
          roles: ["admin", "super_admin"],
        },
      ],
    },
    {
      section: "Staff",
      items: [
        {
          title: "Instructors",
          href: "/staff/instructors",
          icon: <User className="h-5 w-5" />,
          roles: ["admin", "super_admin"],
        },
        {
          title: "Administrators",
          href: "/staff/admins",
          icon: <UserCog className="h-5 w-5" />,
          roles: ["super_admin"],
        },
      ],
    },
    {
      section: "Payments",
      items: [
        {
          title: "Transactions",
          href: "/payments/transactions",
          icon: <CreditCard className="h-5 w-5" />,
          roles: ["admin", "super_admin"],
        },
        {
          title: "Reports",
          href: "/payments/reports",
          icon: <FileText className="h-5 w-5" />,
          roles: ["admin", "super_admin"],
        },
      ],
    },
    {
      section: "System",
      items: [
        {
          title: "Settings",
          href: "/settings",
          icon: <Settings className="h-5 w-5" />,
          roles: ["admin", "super_admin"],
        },
      ],
    },
  ];

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={onClose}
        ></div>
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "bg-white border-r border-neutral-200 w-64 fixed inset-y-0 mt-16 z-50 lg:z-0 lg:relative lg:mt-0 shadow-sm",
          isOpen ? "left-0" : "-left-full lg:left-0",
          "transition-all duration-200"
        )}
      >
        <ScrollArea className="h-full py-4">
          <nav className="px-4 space-y-6">
            {links.map((section, i) => (
              <div key={i} className="mb-4">
                {section.items.some(link => canView(link.roles)) && (
                  <>
                    <p className="text-xs font-semibold text-neutral-500 uppercase tracking-wider pl-3 mb-2">
                      {section.section}
                    </p>
                    <div className="space-y-1">
                      {section.items.filter(link => canView(link.roles)).map((link, j) => (
                        <Button
                          key={j}
                          variant="ghost"
                          className={cn(
                            "w-full justify-start",
                            location === link.href
                              ? "bg-primary-50 text-primary-600"
                              : "hover:bg-neutral-100 text-neutral-600"
                          )}
                          onClick={() => setLocation(link.href)}
                        >
                          {link.icon}
                          <span className="ml-2">{link.title}</span>
                        </Button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            ))}

            <Button
              variant="ghost"
              className="w-full justify-start hover:bg-neutral-100 text-neutral-600"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5" />
              <span className="ml-2">Logout</span>
            </Button>
          </nav>
        </ScrollArea>
      </aside>
    </>
  );
}
