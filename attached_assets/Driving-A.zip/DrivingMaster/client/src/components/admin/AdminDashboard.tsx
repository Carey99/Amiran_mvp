import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import StudentTable from "./StudentTable";
import PaymentsTable from "./PaymentsTable";
import AddInstructorModal from "./AddInstructorModal";
import { UserPlus, RefreshCcw, Users, DollarSign, UserCheck, Calendar } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

// Define Student interface locally
interface Student {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  idNumber: string;
  address: string;
  courseType: string;
  branch: string;
  status: string;
  balance: number;
  registrationDate: string;
  instructorId: number | null;
  lessonsCompleted: number;
  totalLessons: number;
  comments: string | null;
  nextLessonDate: string | null;
}

// Define Payment interface locally
interface Payment {
  id: number;
  studentId: number;
  amount: number;
  method: string;
  status: string;
  date: string;
  createdAt: string;
  transactionId: string | null;
  metadata: any;
}

interface DashboardStats {
  totalStudents: number;
  activeStudents: number;
  totalRevenue: number;
  pendingPayments: number;
  todayRegistrations: number;
  remindersCount: number;
}

interface AdminDashboardProps {
  isSuperAdmin: boolean;
}

export default function AdminDashboard({ isSuperAdmin }: AdminDashboardProps) {
  const [showAddInstructorModal, setShowAddInstructorModal] = useState(false);

  // Fetch dashboard stats
  const statsQuery = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: async () => {
      const response = await apiRequest<any>("/api/dashboard/stats");
      return response as DashboardStats;
    },
  });

  // Fetch all students
  const allStudentsQuery = useQuery({
    queryKey: ["/api/students/all"],
    queryFn: async () => {
      const response = await apiRequest<any>("/api/students/all");
      return response as Student[];
    },
  });

  // Fetch current students
  const currentStudentsQuery = useQuery({
    queryKey: ["/api/students/current"],
    queryFn: async () => {
      const response = await apiRequest<any>("/api/students/current");
      return response as Student[];
    },
  });

  // Fetch concluded students
  const concludedStudentsQuery = useQuery({
    queryKey: ["/api/students/concluded"],
    queryFn: async () => {
      const response = await apiRequest<any>("/api/students/concluded");
      return response as Student[];
    },
  });

  // Fetch recent payments
  const recentPaymentsQuery = useQuery({
    queryKey: ["/api/payments/recent"],
    queryFn: async () => {
      const response = await apiRequest<any>("/api/payments/recent");
      return response as Payment[];
    },
  });

  const refreshData = () => {
    statsQuery.refetch();
    allStudentsQuery.refetch();
    currentStudentsQuery.refetch();
    concludedStudentsQuery.refetch();
    recentPaymentsQuery.refetch();
  };

  const formatCurrency = (amount: number = 0) => {
    return new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <div className="flex items-center gap-2">
          {isSuperAdmin && (
            <Button onClick={() => setShowAddInstructorModal(true)}>
              <UserPlus className="mr-2 h-4 w-4" />
              Add Instructor
            </Button>
          )}
          <Button variant="outline" onClick={refreshData}>
            <RefreshCcw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {statsQuery.isLoading ? "Loading..." : statsQuery.data?.totalStudents || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              {statsQuery.isLoading
                ? "Loading..."
                : `${statsQuery.data?.todayRegistrations || 0} new today`}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Students</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {statsQuery.isLoading ? "Loading..." : statsQuery.data?.activeStudents || 0}
            </div>
            <p className="text-xs text-muted-foreground">Currently in training</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {statsQuery.isLoading
                ? "Loading..."
                : formatCurrency(statsQuery.data?.totalRevenue || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {statsQuery.isLoading
                ? "Loading..."
                : `${formatCurrency(statsQuery.data?.pendingPayments || 0)} pending`}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="current" className="space-y-4">
        <TabsList>
          <TabsTrigger value="current">Current Students</TabsTrigger>
          <TabsTrigger value="all">All Students</TabsTrigger>
          <TabsTrigger value="concluded">Concluded</TabsTrigger>
          <TabsTrigger value="payments">Recent Payments</TabsTrigger>
        </TabsList>
        <TabsContent value="current" className="space-y-4">
          {currentStudentsQuery.isLoading ? (
            <div className="flex justify-center p-4">Loading current students...</div>
          ) : (
            <StudentTable
              students={currentStudentsQuery.data || []}
              title="Current Students"
            />
          )}
        </TabsContent>
        <TabsContent value="all" className="space-y-4">
          {allStudentsQuery.isLoading ? (
            <div className="flex justify-center p-4">Loading all students...</div>
          ) : (
            <StudentTable
              students={allStudentsQuery.data || []}
              title="All Students"
            />
          )}
        </TabsContent>
        <TabsContent value="concluded" className="space-y-4">
          {concludedStudentsQuery.isLoading ? (
            <div className="flex justify-center p-4">Loading concluded students...</div>
          ) : (
            <StudentTable
              students={concludedStudentsQuery.data || []}
              title="Concluded Students"
            />
          )}
        </TabsContent>
        <TabsContent value="payments" className="space-y-4">
          {recentPaymentsQuery.isLoading ? (
            <div className="flex justify-center p-4">Loading recent payments...</div>
          ) : (
            <PaymentsTable
              payments={recentPaymentsQuery.data || []}
              title="Recent Payments"
            />
          )}
        </TabsContent>
      </Tabs>

      <AddInstructorModal
        isOpen={showAddInstructorModal}
        onClose={() => setShowAddInstructorModal(false)}
      />
    </div>
  );
}