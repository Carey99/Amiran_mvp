import { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, QueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const paymentSchema = z.object({
  amount: z.coerce.number().min(1, 'Amount must be greater than 0'),
  phone: z.string().min(10, 'Phone number must be at least 10 digits'),
});

type PaymentFormProps = {
  studentId: string;
  studentName: string;
  balance: number;
  onPaymentComplete: () => void;
};

export default function PaymentForm({ studentId, studentName, balance, onPaymentComplete }: PaymentFormProps) {
  const { toast } = useToast();
  const [transactionState, setTransactionState] = useState<{
    status: 'idle' | 'pending' | 'complete' | 'error';
    message?: string;
    paymentId?: string;
    transactionId?: string;
  }>({
    status: 'idle',
  });

  const form = useForm<z.infer<typeof paymentSchema>>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      amount: balance,
      phone: '',
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: z.infer<typeof paymentSchema>) => {
      return apiRequest<{ paymentId: string; transactionId: string }>('/api/payments/mpesa', {
        method: 'POST',
        body: JSON.stringify({
          ...data,
          studentId,
        }),
      });
    },
    onSuccess: (data) => {
      setTransactionState({
        status: 'pending',
        message: 'Payment initiated. Please check your phone to complete the transaction.',
        paymentId: data.paymentId,
        transactionId: data.transactionId,
      });
      
      // Poll for payment status
      pollPaymentStatus(data.transactionId);
    },
    onError: (error: any) => {
      setTransactionState({
        status: 'error',
        message: error.message || 'Failed to initiate payment. Please try again.',
      });
      
      toast({
        title: 'Payment Error',
        description: error.message || 'Failed to initiate payment',
        variant: 'destructive',
      });
    },
  });

  const confirmMutation = useMutation({
    mutationFn: async (transactionId: string) => {
      return apiRequest<{ success: boolean }>(`/api/payments/confirm/${transactionId}`, {
        method: 'POST',
        body: JSON.stringify({
          paymentId: transactionState.paymentId,
        }),
      });
    },
    onSuccess: () => {
      setTransactionState({
        status: 'complete',
        message: 'Payment completed successfully!',
      });
      
      toast({
        title: 'Payment Successful',
        description: 'The payment has been processed successfully',
      });
      
      onPaymentComplete();
    },
    onError: (error: any) => {
      setTransactionState({
        status: 'error',
        message: error.message || 'Failed to confirm payment. Please try again.',
      });
      
      toast({
        title: 'Confirmation Error',
        description: error.message || 'Failed to confirm payment',
        variant: 'destructive',
      });
    },
  });

  async function pollPaymentStatus(transactionId: string) {
    // In a real implementation, we would poll the server to check the payment status
    // For this mock, we'll just set a timeout to simulate the payment completion
    setTimeout(() => {
      // Simulate a successful payment (in real app, this would be based on actual status)
      if (Math.random() > 0.3) { // 70% success rate for demo
        confirmMutation.mutate(transactionId);
      } else {
        setTransactionState({
          status: 'error',
          message: 'Payment was not completed. The customer may have cancelled the request.',
        });
      }
    }, 10000); // 10 seconds delay to simulate M-Pesa processing time
  }

  function onSubmit(data: z.infer<typeof paymentSchema>) {
    mutation.mutate(data);
  }

  function handleManualConfirmation() {
    if (transactionState.transactionId) {
      confirmMutation.mutate(transactionState.transactionId);
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Payment for {studentName}</CardTitle>
      </CardHeader>
      <CardContent>
        {transactionState.status === 'idle' && (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (KES)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. 0712345678" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                className="w-full" 
                disabled={mutation.isPending}
              >
                {mutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Pay with M-Pesa'
                )}
              </Button>
            </form>
          </Form>
        )}

        {transactionState.status === 'pending' && (
          <div className="space-y-4">
            <Alert>
              <Loader2 className="h-4 w-4 animate-spin" />
              <AlertTitle>Payment in Progress</AlertTitle>
              <AlertDescription>
                {transactionState.message}
                <div className="mt-2 text-sm text-muted-foreground">
                  Transaction ID: {transactionState.transactionId}
                </div>
              </AlertDescription>
            </Alert>
            <Button 
              onClick={handleManualConfirmation} 
              variant="outline" 
              className="w-full"
              disabled={confirmMutation.isPending}
            >
              {confirmMutation.isPending ? 'Checking...' : 'Check Payment Status'}
            </Button>
          </div>
        )}

        {transactionState.status === 'complete' && (
          <Alert variant="default" className="bg-green-50 border-green-200">
            <CheckCircle2 className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-600">Payment Successful</AlertTitle>
            <AlertDescription className="text-green-700">
              {transactionState.message}
            </AlertDescription>
          </Alert>
        )}

        {transactionState.status === 'error' && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Payment Failed</AlertTitle>
            <AlertDescription>
              {transactionState.message}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        {transactionState.status !== 'idle' && (
          <Button 
            variant="outline" 
            onClick={() => setTransactionState({ status: 'idle' })}
            className="w-full"
            disabled={mutation.isPending || confirmMutation.isPending}
          >
            Try Again
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}