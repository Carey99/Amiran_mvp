import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import PaymentForm from "./PaymentForm";
import { useQueryClient } from "@tanstack/react-query";

type PaymentModalProps = {
  isOpen: boolean;
  onClose: () => void;
  studentId: string;
  studentName: string;
  balance: number;
};

export default function PaymentModal({
  isOpen,
  onClose,
  studentId,
  studentName,
  balance,
}: PaymentModalProps) {
  const queryClient = useQueryClient();

  const handlePaymentComplete = () => {
    // Invalidate queries to refresh data
    queryClient.invalidateQueries({ queryKey: ['/api/students/all'] });
    queryClient.invalidateQueries({ queryKey: ['/api/students/current'] });
    queryClient.invalidateQueries({ queryKey: [`/api/students/${studentId}`] });
    queryClient.invalidateQueries({ queryKey: ['/api/payments/recent'] });
    
    // Close the modal after a delay to show the success message
    setTimeout(onClose, 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Process Payment</DialogTitle>
          <DialogDescription>
            Complete payment via M-Pesa for student {studentName}
          </DialogDescription>
        </DialogHeader>
        <PaymentForm
          studentId={studentId}
          studentName={studentName}
          balance={balance}
          onPaymentComplete={handlePaymentComplete}
        />
      </DialogContent>
    </Dialog>
  );
}