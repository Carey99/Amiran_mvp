import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MoreHorizontal, CreditCard, Eye } from "lucide-react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import PaymentModal from "./PaymentModal";

// Define Student interface locally since we can't import from schema
interface Student {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  idNumber: string;
  address: string;
  courseType: string;
  branch: string;
  status: string;
  balance: number;
  registrationDate: string;
  instructorId: number | null;
  lessonsCompleted: number;
  totalLessons: number;
  comments: string | null;
  nextLessonDate: string | null;
}

interface StudentTableProps {
  students: Student[];
  title?: string;
  showActions?: boolean;
}

export default function StudentTable({ 
  students, 
  title = "Students", 
  showActions = true 
}: StudentTableProps) {
  const [, navigate] = useLocation();
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const handleViewStudent = (studentId: number) => {
    navigate(`/students/${studentId}`);
  };

  const handlePayment = (student: Student) => {
    setSelectedStudent(student);
    setShowPaymentModal(true);
  };

  const formatStatus = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Active</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Pending</Badge>;
      case "completed":
        return <Badge variant="default">Completed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatCourseType = (courseType: string) => {
    switch (courseType) {
      case "class-a":
        return "Class A";
      case "class-b-manual":
        return "Class B (Manual)";
      case "class-b-auto":
        return "Class B (Auto)";
      case "class-c":
        return "Class C";
      case "defensive-driving":
        return "Defensive Driving";
      default:
        return courseType;
    }
  };

  const formatBranch = (branch: string) => {
    switch (branch) {
      case "kahawa-sukari":
        return "Kahawa Sukari";
      case "mwihoko":
        return "Mwihoko";
      default:
        return branch;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "PPP");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">{title}</h2>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Course</TableHead>
              <TableHead>Branch</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Balance</TableHead>
              <TableHead>Reg. Date</TableHead>
              {showActions && <TableHead className="text-right">Actions</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {students.length === 0 ? (
              <TableRow>
                <TableCell colSpan={showActions ? 7 : 6} className="text-center py-8 text-muted-foreground">
                  No students found
                </TableCell>
              </TableRow>
            ) : (
              students.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>
                    <div className="font-medium">{student.fullName}</div>
                    <div className="text-sm text-muted-foreground">{student.email}</div>
                  </TableCell>
                  <TableCell>{formatCourseType(student.courseType)}</TableCell>
                  <TableCell>{formatBranch(student.branch)}</TableCell>
                  <TableCell>{formatStatus(student.status)}</TableCell>
                  <TableCell>
                    {student.balance > 0 ? (
                      <div className="font-semibold text-destructive">
                        {formatCurrency(student.balance)}
                      </div>
                    ) : (
                      <div className="font-medium text-success">Paid</div>
                    )}
                  </TableCell>
                  <TableCell>{formatDate(student.registrationDate)}</TableCell>
                  {showActions && (
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewStudent(student.id)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </DropdownMenuItem>
                          {student.balance > 0 && (
                            <DropdownMenuItem onClick={() => handlePayment(student)}>
                              <CreditCard className="mr-2 h-4 w-4" />
                              Process Payment
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  )}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {selectedStudent && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          studentId={selectedStudent.id.toString()}
          studentName={selectedStudent.fullName}
          balance={selectedStudent.balance}
        />
      )}
    </div>
  );
}