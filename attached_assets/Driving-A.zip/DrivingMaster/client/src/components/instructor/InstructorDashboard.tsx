import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Calendar, FileCheck } from "lucide-react";
import PaymentModal from "./PaymentModal";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

export default function InstructorDashboard() {
  const [, navigate] = useLocation();
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: instructorData, isLoading } = useQuery({
    queryKey: ["/api/instructors/dashboard"],
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!instructorData) {
    return (
      <div className="p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>Failed to load instructor dashboard. Please try again.</AlertDescription>
        </Alert>
      </div>
    );
  }

  const { instructor, activeStudents, upcomingLessons, recentLessons } = instructorData;

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  const handleOpenPaymentModal = (student: any) => {
    setSelectedStudent(student);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentComplete = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/instructors/dashboard"] });
    setIsPaymentModalOpen(false);
    toast({
      title: "Payment Successful",
      description: `Payment has been processed successfully for ${selectedStudent.fullName}.`,
    });
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-heading font-semibold text-neutral-800">Instructor Dashboard</h1>
        <p className="text-neutral-500">Welcome back, {instructor.name}! Here's an overview of your students and lessons.</p>
      </div>

      {/* Instructor Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-neutral-500 font-medium">Active Students</h3>
              <span className="bg-primary-100 text-primary-700 p-2 rounded-full">
                <FileCheck className="h-5 w-5" />
              </span>
            </div>
            <div className="flex items-baseline">
              <p className="text-2xl font-semibold">{activeStudents.length}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-neutral-500 font-medium">Today's Lessons</h3>
              <span className="bg-secondary-100 text-secondary-700 p-2 rounded-full">
                <Calendar className="h-5 w-5" />
              </span>
            </div>
            <div className="flex items-baseline">
              <p className="text-2xl font-semibold">{upcomingLessons.filter((lesson: any) => {
                const today = new Date().toISOString().split('T')[0];
                return lesson.date.split('T')[0] === today;
              }).length}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-neutral-500 font-medium">Completed Lessons</h3>
              <span className="bg-accent-100 text-accent-700 p-2 rounded-full">
                <FileCheck className="h-5 w-5" />
              </span>
            </div>
            <div className="flex items-baseline">
              <p className="text-2xl font-semibold">{recentLessons.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Students */}
      <div className="grid grid-cols-1 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Current Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Student
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Course
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Progress
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Next Lesson
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Balance
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {activeStudents.map((student: any) => (
                    <tr key={student.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback className="bg-primary-100 text-primary-600">
                              {getInitials(student.fullName)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-neutral-900">{student.fullName}</div>
                            <div className="text-sm text-neutral-500">{student.phone}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-neutral-900">
                          {student.courseType === "class-a" && "Class A (Motorcycle)"}
                          {student.courseType === "class-b-manual" && "Class B (Manual)"}
                          {student.courseType === "class-b-auto" && "Class B (Automatic)"}
                          {student.courseType === "class-c" && "Class C (Commercial)"}
                          {student.courseType === "defensive-driving" && "Defensive Driving"}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-neutral-900">
                          {student.completedLessons.length} / {student.totalLessons} Lessons
                        </div>
                        <div className="w-full bg-neutral-200 rounded-full h-1.5 mt-1">
                          <div 
                            className="bg-primary h-1.5 rounded-full" 
                            style={{ width: `${(student.completedLessons.length / student.totalLessons) * 100}%` }}
                          ></div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                        {student.nextLessonDate 
                          ? new Date(student.nextLessonDate).toLocaleDateString() 
                          : "Not Scheduled"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {student.balance > 0 ? (
                          <Badge variant="outline" className="text-red-500 border-red-200">
                            KES {student.balance.toLocaleString()}
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-green-500 border-green-200">
                            Paid
                          </Badge>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <Button 
                          variant="link" 
                          className="text-primary-600 font-medium mr-2"
                          onClick={() => navigate(`/students/${student.id}`)}
                        >
                          View
                        </Button>
                        {student.balance > 0 && (
                          <Button 
                            variant="default"
                            size="sm"
                            onClick={() => handleOpenPaymentModal(student)}
                          >
                            Make Payment
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}

                  {activeStudents.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-6 py-8 text-center text-sm text-neutral-500">
                        You currently have no active students
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Lessons */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Lessons</CardTitle>
          </CardHeader>
          <CardContent>
            {upcomingLessons.length > 0 ? (
              <div className="space-y-4">
                {upcomingLessons.map((lesson: any) => (
                  <div key={lesson.id} className="flex items-center justify-between p-4 border rounded-md">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-primary-100 text-primary-600">
                          {getInitials(lesson.studentName)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="ml-4">
                        <div className="text-sm font-medium">{lesson.studentName}</div>
                        <div className="text-xs text-neutral-500">
                          Lesson {lesson.lessonNumber} • {new Date(lesson.date).toLocaleDateString()} • {lesson.time}
                        </div>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => navigate(`/students/${lesson.studentId}`)}
                    >
                      Details
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-neutral-500">
                No upcoming lessons scheduled
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Lessons</CardTitle>
          </CardHeader>
          <CardContent>
            {recentLessons.length > 0 ? (
              <div className="space-y-4">
                {recentLessons.map((lesson: any) => (
                  <div key={lesson.id} className="flex items-center justify-between p-4 border rounded-md">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-secondary-100 text-secondary-600">
                          {getInitials(lesson.studentName)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="ml-4">
                        <div className="text-sm font-medium">{lesson.studentName}</div>
                        <div className="text-xs text-neutral-500">
                          Lesson {lesson.lessonNumber} • {new Date(lesson.date).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => window.open(`/api/receipts/${lesson.id}`, '_blank')}
                    >
                      Print Receipt
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-neutral-500">
                No recent lessons completed
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {selectedStudent && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          studentId={selectedStudent.id}
          studentName={selectedStudent.fullName}
          studentPhone={selectedStudent.phone}
          amount={selectedStudent.balance}
          onPaymentComplete={handlePaymentComplete}
        />
      )}
    </div>
  );
}
