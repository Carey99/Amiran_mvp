import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FileCheck, Calendar, Clock, UserCheck } from "lucide-react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface Lesson {
  id: string;
  lessonNumber: number;
  date: string;
  notes: string;
  instructor: string;
}

interface LessonTrackerProps {
  studentId: string;
  lessons: Lesson[];
  totalLessons: number;
  canAddLessons: boolean;
}

export default function LessonTracker({ studentId, lessons, totalLessons, canAddLessons }: LessonTrackerProps) {
  const [isAddingLesson, setIsAddingLesson] = useState(false);
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleAddLesson = async () => {
    if (!canAddLessons) {
      toast({
        title: "Cannot Add Lesson",
        description: "Student has reached the lesson limit or has an outstanding balance",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await apiRequest("POST", `/api/students/${studentId}/lessons`, { notes });
      toast({
        title: "Lesson Added",
        description: "Lesson has been successfully recorded",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/students/${studentId}`] });
      setIsAddingLesson(false);
      setNotes("");
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add lesson",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Sort lessons by lesson number
  const sortedLessons = [...lessons].sort((a, b) => a.lessonNumber - b.lessonNumber);

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-medium text-lg">Lesson History</h3>
        <Button 
          onClick={() => setIsAddingLesson(true)} 
          disabled={!canAddLessons || sortedLessons.length >= totalLessons}
        >
          Mark Lesson Complete
        </Button>
      </div>

      {sortedLessons.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sortedLessons.map((lesson) => (
            <Card key={lesson.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="p-4 bg-primary-50 border-b flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="p-2 rounded-full bg-primary-100 mr-3">
                      <FileCheck className="h-5 w-5 text-primary-600" />
                    </div>
                    <span className="font-medium">Lesson {lesson.lessonNumber}</span>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open(`/api/receipts/${lesson.id}`, '_blank')}
                  >
                    Print Receipt
                  </Button>
                </div>
                <div className="p-4">
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 text-neutral-500 mr-2" />
                      <span className="text-sm text-neutral-600">
                        {new Date(lesson.date).toLocaleDateString()} 
                      </span>
                    </div>
                    <div className="flex items-center">
                      <UserCheck className="h-4 w-4 text-neutral-500 mr-2" />
                      <span className="text-sm text-neutral-600">
                        Instructor: {lesson.instructor}
                      </span>
                    </div>
                    {lesson.notes && (
                      <div className="mt-3">
                        <h4 className="text-sm font-medium mb-1">Notes:</h4>
                        <p className="text-sm text-neutral-600 bg-neutral-50 p-2 rounded">
                          {lesson.notes}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 border rounded-md bg-neutral-50">
          <FileCheck className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-neutral-600">No Lessons Completed</h3>
          <p className="text-neutral-500 mt-1">This student hasn't completed any lessons yet.</p>
        </div>
      )}

      {!canAddLessons && sortedLessons.length >= 13 && sortedLessons.length < totalLessons && (
        <div className="mt-4 p-4 border border-amber-200 bg-amber-50 rounded-md">
          <p className="text-amber-800 text-sm">
            <strong>Note:</strong> This student has completed 13 lessons and has an outstanding balance. 
            Further lessons are restricted until payment is received.
          </p>
        </div>
      )}

      <Dialog open={isAddingLesson} onOpenChange={setIsAddingLesson}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mark Lesson as Complete</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="notes">Lesson Notes (Optional)</Label>
              <Textarea
                id="notes"
                placeholder="Add any notes about the student's progress or areas to focus on"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddingLesson(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddLesson} disabled={isSubmitting}>
              {isSubmitting ? (
                <div className="flex items-center">
                  <div className="animate-spin mr-2 h-4 w-4 border-t-2 border-b-2 border-white rounded-full"></div>
                  <span>Saving...</span>
                </div>
              ) : (
                "Complete Lesson"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
