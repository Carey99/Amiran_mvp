import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Check } from "lucide-react";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentId: string;
  studentName: string;
  studentPhone: string;
  amount: number;
  onPaymentComplete: () => void;
}

export default function PaymentModal({
  isOpen,
  onClose,
  studentId,
  studentName,
  studentPhone,
  amount,
  onPaymentComplete
}: PaymentModalProps) {
  const [paymentStep, setPaymentStep] = useState<'init' | 'processing' | 'success' | 'error'>('init');
  const [paymentAmount, setPaymentAmount] = useState<number>(amount);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const { toast } = useToast();

  const handleInitiatePayment = async () => {
    if (paymentAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid payment amount",
        variant: "destructive",
      });
      return;
    }

    setPaymentStep('processing');

    try {
      await apiRequest("POST", `/api/payments/mpesa`, {
        studentId,
        amount: paymentAmount,
        phoneNumber: studentPhone,
      });
      
      // In a real application, we would wait for a callback from the M-Pesa API
      // For this demo, we'll simulate a success after a short delay
      setTimeout(() => {
        setPaymentStep('success');
      }, 3000);
    } catch (error) {
      setPaymentStep('error');
      setErrorMessage(error instanceof Error ? error.message : "Payment processing failed");
    }
  };

  const handleClose = () => {
    if (paymentStep === 'success') {
      onPaymentComplete();
    }
    setPaymentStep('init');
    setErrorMessage("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Process M-Pesa Payment</DialogTitle>
          <DialogDescription>
            Initiate a payment request for {studentName}
          </DialogDescription>
        </DialogHeader>

        {paymentStep === 'init' && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Payment Amount (KES)</Label>
              <Input
                id="amount"
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(Number(e.target.value))}
                min={1}
                max={amount}
              />
              <p className="text-sm text-muted-foreground">
                Outstanding balance: KES {amount.toLocaleString()}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="text"
                value={studentPhone}
                disabled
              />
              <p className="text-sm text-muted-foreground">
                The student will receive an M-Pesa payment prompt on this number
              </p>
            </div>
          </div>
        )}

        {paymentStep === 'processing' && (
          <div className="py-8 flex flex-col items-center justify-center space-y-4">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <div className="text-center">
              <h3 className="font-medium text-lg">Processing Payment</h3>
              <p className="text-neutral-500 mt-1">
                M-Pesa payment request has been sent to {studentPhone}.
                <br />
                Waiting for the student to enter their PIN...
              </p>
            </div>
          </div>
        )}

        {paymentStep === 'success' && (
          <div className="py-8 flex flex-col items-center justify-center space-y-4">
            <div className="rounded-full bg-green-100 p-3">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <div className="text-center">
              <h3 className="font-medium text-lg">Payment Successful!</h3>
              <p className="text-neutral-500 mt-1">
                KES {paymentAmount.toLocaleString()} has been received
                <br />
                Transaction ID: TXN-{Math.floor(Math.random() * 900000) + 100000}
              </p>
            </div>
          </div>
        )}

        {paymentStep === 'error' && (
          <div className="py-8 flex flex-col items-center justify-center space-y-4">
            <div className="rounded-full bg-red-100 p-3">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-red-600"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </div>
            <div className="text-center">
              <h3 className="font-medium text-lg">Payment Failed</h3>
              <p className="text-neutral-500 mt-1">
                {errorMessage || "There was an error processing the payment."}
              </p>
            </div>
          </div>
        )}

        <DialogFooter className="flex justify-between">
          {paymentStep === 'init' && (
            <>
              <Button variant="outline" onClick={handleClose}>
                Cancel
              </Button>
              <Button onClick={handleInitiatePayment}>
                Send M-Pesa Request
              </Button>
            </>
          )}

          {paymentStep === 'processing' && (
            <Button variant="outline" onClick={handleClose} className="w-full">
              Cancel Payment
            </Button>
          )}

          {(paymentStep === 'success' || paymentStep === 'error') && (
            <Button onClick={handleClose} className="w-full">
              {paymentStep === 'success' ? 'Done' : 'Try Again'}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
