import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  name: string;
  username: string;
  email: string;
  role: "super_admin" | "admin" | "instructor";
}

interface InstructorDetails {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  specialization: string;
  experience: number | null;
  active: boolean;
}

interface AuthContextType {
  user: User | null;
  instructorDetails: InstructorDetails | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Use TanStack Query to get the current user
  const { 
    data: authData, 
    isLoading: isLoadingUser,
    error: authError
  } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      const response = await apiRequest("/api/auth/me", { method: "GET" });
      return response;
    },
    retry: false,
    refetchOnWindowFocus: false,
  });

  const user = authData?.success ? authData.user : null;
  const instructorDetails = authData?.success ? authData.instructorDetails : null;

  const login = async (username: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const response = await apiRequest("/api/auth/login", {
        method: "POST",
        body: { username, password }
      });
      
      if (response.success) {
        await queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        toast({
          title: "Login successful",
          description: `Welcome back, ${response.user.name}!`,
        });
        return true;
      } else {
        toast({
          variant: "destructive",
          title: "Login failed",
          description: response.message || "Invalid username or password",
        });
        return false;
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Login failed",
        description: error.message || "An error occurred during login",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      await apiRequest("/api/auth/logout", { method: "POST" });
      await queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      queryClient.clear();
      
      toast({
        title: "Logged out",
        description: "You have been successfully logged out",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: error.message || "An error occurred during logout",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      instructorDetails, 
      isLoading: isLoading || isLoadingUser, 
      login, 
      logout 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
