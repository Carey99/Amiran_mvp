import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import AppLayout from "@/components/AppLayout";
import AdminDashboard from "@/components/admin/AdminDashboard";
import InstructorDashboard from "@/components/instructor/InstructorDashboard";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
      toast({
        title: "Authentication Required",
        description: "Please log in to access the dashboard",
        variant: "destructive",
      });
    }
  }, [user, isLoading, setLocation, toast]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect to login
  }

  return (
    <AppLayout>
      {user.role === "super_admin" || user.role === "admin" ? (
        <AdminDashboard isSuperAdmin={user.role === "super_admin"} />
      ) : (
        <InstructorDashboard />
      )}
    </AppLayout>
  );
}
