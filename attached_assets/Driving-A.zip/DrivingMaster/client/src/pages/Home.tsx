import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { Calendar, GraduationCap, Car, Award, MapPin, Clock } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-100">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-100 to-indigo-100 opacity-50"></div>
        
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="lg:w-1/2 space-y-6">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900">
                  Drive Your <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Future</span>
                </h1>
                <p className="text-xl md:text-2xl mt-4 text-gray-700">
                  Amiran Driving College - Perfecting Your Ride with Confidence
                </p>
              </motion.div>
              
              <motion.p 
                className="text-gray-600 text-lg"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
              >
                Join thousands of successful drivers who started their journey with us. 
                Professional instructors, modern vehicles, and personalized lessons designed to 
                help you become a confident and skilled driver.
              </motion.p>
              
              <motion.div
                className="flex flex-wrap gap-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.5 }}
              >
                <Link href="/apply">
                  <Button size="lg" className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold px-8 py-6 rounded-lg text-lg">
                    Apply Now
                  </Button>
                </Link>
                <Button variant="outline" size="lg" className="border-blue-600 text-blue-600 px-8 py-6 rounded-lg text-lg">
                  Learn More
                </Button>
              </motion.div>
              
              <motion.div
                className="flex items-center gap-2 text-gray-600"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.5 }}
              >
                <Clock className="h-5 w-5 text-blue-500" />
                <span>Classes available 7 days a week</span>
              </motion.div>
            </div>
            
            <motion.div 
              className="lg:w-1/2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.7 }}
            >
              <div className="relative rounded-xl overflow-hidden shadow-2xl">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-indigo-600/20"></div>
                <img 
                  src="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" 
                  alt="Driving Lesson" 
                  className="w-full h-auto rounded-xl"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Why Choose Amiran Driving School?</h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              We provide a highly discounted, NTSA approved comprehensive driver cirriculum with a focus on safety, 
              confidence, and skill development.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<GraduationCap className="h-12 w-12 text-blue-500" />}
              title="Expert Instructors"
              description="Learn from certified instructors with years of experience in driver training."
            />
            <FeatureCard 
              icon={<Car className="h-12 w-12 text-blue-500" />}
              title="Modern Vehicles"
              description="Practice with well-maintained, dual-control vehicles for a safe learning experience."
            />
            <FeatureCard 
              icon={<Calendar className="h-12 w-12 text-blue-500" />}
              title="Flexible Scheduling"
              description="Choose class times that fit your busy schedule, including evenings and weekends."
            />
            <FeatureCard 
              icon={<Award className="h-12 w-12 text-blue-500" />}
              title="High Pass Rates"
              description="Our students consistently achieve higher-than-average pass rates on driving tests."
            />
            <FeatureCard 
              icon={<MapPin className="h-12 w-12 text-blue-500" />}
              title="Convenient Locations"
              description="Two convenient branches in Kahawa Sukari and Mwihoko to serve you better."
            />
            <FeatureCard 
              icon={<Clock className="h-12 w-12 text-blue-500" />}
              title="Quick Progress"
              description="Structured curriculum designed to help you learn efficiently and progress quickly."
            />
          </div>
        </div>
      </section>
      
      {/* Course Types Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Our Courses</h2>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
              We offer a variety of driving courses to meet your specific needs and goals.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <CourseCard 
              title="Class A2 (Motorcycle)"
              description="Learn to ride motorcycles safely and confidently. Includes both on-road and off-road training."
              price="KES 5,000"
              lessons="12 Lessons"
            />
            <CourseCard 
              title="Class B (Manual)"
              description="Master manual transmission driving with comprehensive training on all aspects of vehicle control."
              price="KES 11,000"
              lessons="24 Lessons"
              featured={true}
            />
            <CourseCard 
              title="Class B (Automatic)"
              description="Learn to drive automatic transmission vehicles with ease. Perfect for urban driving."
              price="KES 11,000"
              lessons="24 Lessons"
            />
            <CourseCard 
              title="Class C (Commercial)"
              description="Professional training for commercial driving licenses. Prepare for a career in transportation."
              price="KES 11,000"
              lessons="24 Lessons"
            />
            <CourseCard 
              title="Defensive Driving"
              description="Advanced course focused on anticipation, hazard perception, and accident avoidance."
              price="KES 15,000"
              lessons="10 Lessons"
            />
            <CourseCard 
              title="Refresher Course"
              description="Brush up on your driving skills after a break or build confidence with additional practice."
              price="KES 5000"
              lessons="1 Lesson"
            />
          </div>
        </div>
      </section>
      
      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your Driving Journey?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Apply today and take the first step toward becoming a confident, skilled driver.
          </p>
          <Link href="/apply">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 font-semibold px-8 py-6 rounded-lg text-lg">
              Apply Now
            </Button>
          </Link>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Amiran Driving College</h3>
              <p className="text-gray-400">
                Excellence in driver training. Helping new drivers gain confidence and skills.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Contact Us</h3>
              <p className="text-gray-400">Kahawa Sukari Branch: +254 708 538 416</p>
              <p className="text-gray-400">Mwihoko Branch: +254 708 538 416</p>
              <p className="text-gray-400">Email: info@amirandriving.co.ke</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Opening Hours</h3>
              <p className="text-gray-400">Monday - Friday: 7:00 AM - 6:00 PM</p>
              <p className="text-gray-400">Saturday: 9:00 AM - 6:00 PM</p>
              <p className="text-gray-400">Sunday: 3:00 PM - 6:00 PM</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Our Courses</a></li>
                <li><a href="#" className="hover:text-white">Instructors</a></li>
                <li><a href="#" className="hover:text-white">Locations</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Amiran Driving School. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Feature Card Component
function FeatureCard({ icon, title, description }: { 
  icon: React.ReactNode; 
  title: string; 
  description: string 
}) {
  return (
    <Card className="border border-gray-200 hover:shadow-lg transition-shadow duration-300">
      <CardContent className="pt-6">
        <div className="flex flex-col items-center text-center">
          <div className="mb-4">{icon}</div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
}

// Course Card Component
function CourseCard({ title, description, price, lessons, featured = false }: { 
  title: string; 
  description: string; 
  price: string;
  lessons: string;
  featured?: boolean;
}) {
  return (
    <Card className={`border ${featured ? 'border-blue-500 shadow-xl' : 'border-gray-200'} hover:shadow-lg transition-shadow duration-300 overflow-hidden`}>
      {featured && (
        <div className="bg-blue-500 text-white text-center py-1 text-sm font-semibold">
          Most Popular
        </div>
      )}
      <CardContent className={`pt-6 ${featured ? 'pb-6' : ''}`}>
        <div className="flex flex-col h-full">
          <h3 className={`text-xl font-bold ${featured ? 'text-blue-600' : 'text-gray-900'} mb-2`}>{title}</h3>
          <p className="text-gray-600 mb-4 flex-grow">{description}</p>
          <div className="flex justify-between items-center border-t border-gray-200 pt-4">
            <div className="text-lg font-bold text-gray-900">{price}</div>
            <div className="text-gray-600">{lessons}</div>
          </div>
          {featured && (
            <Link href="/apply">
              <Button className="w-full mt-4 bg-gradient-to-r from-blue-600 to-indigo-600">
                Apply Now
              </Button>
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
}