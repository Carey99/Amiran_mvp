import { useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import PaymentModal from "@/components/instructor/PaymentModal";
import LessonTracker from "@/components/instructor/LessonTracker";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { AlertCircle, Info } from "lucide-react";

export default function StudentView() {
  const [, params] = useRoute("/students/:id");
  const [, navigate] = useLocation();
  const studentId = params?.id;
  const { user } = useAuth();
  const { toast } = useToast();
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState(0);

  const { data: student, isLoading, error } = useQuery({
    queryKey: [`/api/students/${studentId}`],
    enabled: !!studentId,
  });

  useEffect(() => {
    if (!user) {
      navigate("/login");
      toast({
        title: "Authentication Required",
        description: "Please login to view student details",
        variant: "destructive",
      });
    }
  }, [user, navigate, toast]);

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </AppLayout>
    );
  }

  if (!student || error) {
    return (
      <AppLayout>
        <div className="p-6">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              {error instanceof Error ? error.message : "Could not load student details. Please try again."}
            </AlertDescription>
          </Alert>
        </div>
      </AppLayout>
    );
  }

  const handleModifyBalance = async (amount: number) => {
    if (!user || (user.role !== "super_admin")) {
      toast({
        title: "Permission Denied",
        description: "Only Super Admins can modify student balances",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest("PATCH", `/api/students/${studentId}/balance`, { 
        adjustment: amount 
      });
      toast({
        title: "Balance Updated",
        description: `Student balance has been adjusted by KES ${amount}`,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/students/${studentId}`] });
    } catch (error) {
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Could not update student balance",
        variant: "destructive",
      });
    }
  };

  const handlePaymentClick = () => {
    setPaymentAmount(student.balance);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentComplete = () => {
    queryClient.invalidateQueries({ queryKey: [`/api/students/${studentId}`] });
    setIsPaymentModalOpen(false);
    toast({
      title: "Payment Successful",
      description: `Payment of KES ${paymentAmount} has been received.`,
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>;
      case "pending":
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Payment Pending</Badge>;
      case "completed":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Completed</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <AppLayout>
      <div className="p-6">
        <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-heading font-semibold text-neutral-800">{student.fullName}</h1>
            <p className="text-neutral-500">{student.email} | {student.phone}</p>
          </div>
          <div className="mt-4 md:mt-0 flex space-x-2">
            {student.status === "active" && student.balance > 0 && (
              <Button onClick={handlePaymentClick} variant="secondary">
                Make Payment
              </Button>
            )}
            <Button onClick={() => navigate("/")}>Back to Dashboard</Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Course Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Course Type:</span>
                  <span className="font-medium">
                    {student.courseType === "class-a" && "Class A (Motorcycle)"}
                    {student.courseType === "class-b-manual" && "Class B (Manual)"}
                    {student.courseType === "class-b-auto" && "Class B (Automatic)"}
                    {student.courseType === "class-c" && "Class C (Commercial)"}
                    {student.courseType === "defensive-driving" && "Defensive Driving"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Registration Date:</span>
                  <span className="font-medium">
                    {new Date(student.registrationDate).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Status:</span>
                  <span>{getStatusBadge(student.status)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Lesson Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Completed Lessons:</span>
                  <span className="font-medium">{student.completedLessons.length} / {student.totalLessons}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Next Lesson:</span>
                  <span className="font-medium">
                    {student.nextLessonDate 
                      ? new Date(student.nextLessonDate).toLocaleDateString() 
                      : "Not Scheduled"}
                  </span>
                </div>
                <div className="w-full bg-neutral-200 rounded-full h-2.5">
                  <div 
                    className="bg-primary h-2.5 rounded-full" 
                    style={{ width: `${(student.completedLessons.length / student.totalLessons) * 100}%` }}
                  ></div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Payment Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Course Fee:</span>
                  <span className="font-medium">KES {student.courseFee.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Payments Made:</span>
                  <span className="font-medium">KES {(student.courseFee - student.balance).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Outstanding Balance:</span>
                  <span className="font-medium text-red-600">KES {student.balance.toLocaleString()}</span>
                </div>

                {user?.role === "super_admin" && (
                  <div className="flex justify-between pt-2 border-t border-dashed border-neutral-200 mt-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleModifyBalance(-5000)}
                    >
                      Apply Discount
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleModifyBalance(5000)}
                    >
                      Adjust Fee
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {student.balance > 0 && student.completedLessons.length >= 13 && (
          <Alert className="mb-6">
            <Info className="h-4 w-4" />
            <AlertTitle>Lesson Restriction</AlertTitle>
            <AlertDescription>
              This student has completed 13 lessons and has an outstanding balance. 
              Further lessons are restricted until payment is received.
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="lessons">
          <TabsList>
            <TabsTrigger value="lessons">Lesson History</TabsTrigger>
            <TabsTrigger value="payments">Payment History</TabsTrigger>
            <TabsTrigger value="details">Personal Details</TabsTrigger>
          </TabsList>
          <TabsContent value="lessons" className="border rounded-md p-4 mt-4">
            <LessonTracker 
              studentId={studentId || ""} 
              lessons={student.completedLessons} 
              totalLessons={student.totalLessons}
              canAddLessons={student.balance === 0 || student.completedLessons.length < 13}
            />
          </TabsContent>
          <TabsContent value="payments" className="border rounded-md p-4 mt-4">
            {student.payments && student.payments.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Transaction ID
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Amount
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Method
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {student.payments.map((payment: any) => (
                      <tr key={payment.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                          {payment.transactionId}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                          {new Date(payment.date).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          KES {payment.amount.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                          {payment.method}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge variant={payment.status === "completed" ? "default" : "outline"}>
                            {payment.status}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-neutral-500">
                No payment records found for this student.
              </div>
            )}
          </TabsContent>
          <TabsContent value="details" className="border rounded-md p-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium mb-4">Personal Information</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Full Name:</span>
                    <span>{student.fullName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">ID Number:</span>
                    <span>{student.idNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Email:</span>
                    <span>{student.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Phone:</span>
                    <span>{student.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Address:</span>
                    <span>{student.address}</span>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="font-medium mb-4">Comments</h3>
                <div className="p-3 bg-neutral-50 rounded-md min-h-[100px]">
                  {student.comments || "No additional comments."}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        studentId={studentId || ""}
        studentName={student.fullName}
        studentPhone={student.phone}
        amount={paymentAmount}
        onPaymentComplete={handlePaymentComplete}
      />
    </AppLayout>
  );
}
