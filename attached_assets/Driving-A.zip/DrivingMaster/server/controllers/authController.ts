import { Request, Response } from 'express';
import { storage } from '../storage';
import { z } from 'zod';
import { hashPassword } from '../utils/passwordUtils';

// Login validation schema
const loginSchema = z.object({
  username: z.string().min(3).max(50),
  password: z.string().min(6)
});

// Signup validation schema
const adminSignupSchema = z.object({
  fullname: z.string().min(2),
  email: z.string().email(),
  phone: z.string().min(10),
  password: z.string().min(8),
});

/**
 * Handle admin signup
 */
export const adminSignup = async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = adminSignupSchema.parse(req.body);
    const { fullname, email, phone, password } = validatedData;
    
    // Hash the password before storing it
    const hashedPassword = await hashPassword(validatedData.password);
    
    // Create a new admin user with the storage layer (using MongoStorage.createUser)
    const newUser = await storage.createUser({
      fullname: validatedData.fullname,
      password: hashedPassword,
      email: validatedData.email,
      phone: validatedData.phone,
      role: 'admin' // Ensure role is set appropriately
    });
    
    // Respond with success and the created user data (excluding sensitive fields)
    res.status(201).json({
      success: true,
      message: 'Admin account created successfully',
      user: newUser
    });
    
  } catch (error: any) {
    console.error('Admin signup error:', error);
    
    if (error.name === 'ZodError') {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid signup data',
        errors: error.errors 
      });
    }
    
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to process signup request'
    });
  }
}
/**
 * Handle user login
 */
export const login = async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = loginSchema.parse(req.body);
    const { username, password } = validatedData;
    
    // Try to authenticate the user
    const user = await storage.validateUserCredentials(username, password);
    
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid username or password' });
    }
    
    // Set user ID in session
    req.session!.userId = user.id;
    
    // Return user data (without password)
    const { password: _, ...userWithoutPassword } = user;
    
    return res.status(200).json({
      success: true,
      user: userWithoutPassword,
      message: 'Login successful'
    });
    
  } catch (error: any) {
    console.error('Login error:', error);
    
    if (error.name === 'ZodError') {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid login data',
        errors: error.errors 
      });
    }
    
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to process login request'
    });
  }
};

/**
 * Handle user logout
 */
export const logout = (req: Request, res: Response) => {
  // Clear the session
  req.session.destroy((err) => {
    if (err) {
      console.error('Error destroying session:', err);
      return res.status(500).json({
        success: false,
        message: 'Failed to logout properly'
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Logged out successfully'
    });
  });
};

/**
 * Get current user data
 */
export const getCurrentUser = async (req: Request, res: Response) => {
  try {
    // Check if there's a user in the session
    const userId = req.session?.userId;
    
    if (!userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    // Get the user from storage
    const user = await storage.getUser(userId);
    
    if (!user) {
      // Clear the invalid session
      req.session.destroy((err) => {
        if (err) {
          console.error('Error destroying session:', err);
        }
      });
      return res.status(401).json({ message: 'Invalid session' });
    }
    
    // Remove password from user data
    const { password, ...userWithoutPassword } = user;
    
    // Check if user is an instructor, if so, fetch instructor details
    let instructorDetails = null;
    if (user.role === 'instructor') {
      instructorDetails = await storage.getInstructorByUserId(user.id);
    }
    
    return res.status(200).json({
      success: true,
      user: userWithoutPassword,
      instructorDetails
    });
    
  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch user data'
    });
  }
};