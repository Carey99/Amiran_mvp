import { Request, Response } from "express";
import { storage } from "../storage";

// Get dashboard stats
export const getStats = async (req: Request, res: Response) => {
  try {
    // Get various stats from storage
    const [
      totalStudents,
      currentStudents,
      monthlyRevenue,
      pendingPayments,
      todayRegistrations,
      todayLessons,
      todayRevenue,
      paymentReminders
    ] = await Promise.all([
      storage.getTotalStudentsCount(),
      storage.getCurrentStudentsCount(),
      storage.getMonthlyRevenue(),
      storage.getPendingPaymentsTotal(),
      storage.getTodayRegistrationsCount(),
      storage.getTotalLessonsCompletedToday(),
      storage.getTodayTotalPayments(),
      storage.getPaymentRemindersCount()
    ]);
    
    // Create growth percentages (simulated for demo)
    const studentGrowth = Math.floor(Math.random() * 15) + 5; // 5-20%
    const currentStudentGrowth = Math.floor(Math.random() * 10) + 3; // 3-13%
    const revenueGrowth = Math.floor(Math.random() * 20) + 10; // 10-30%
    const pendingPaymentsGrowth = Math.floor(Math.random() * 8) + 1; // 1-9%
    
    const stats = {
      totalStudents,
      currentStudents,
      monthlyRevenue,
      pendingPayments,
      todayRegistrations,
      todayLessons,
      todayRevenue,
      paymentReminders,
      
      // Growth stats
      studentGrowth,
      currentStudentGrowth,
      revenueGrowth,
      pendingPaymentsGrowth
    };
    
    res.status(200).json(stats);
  } catch (error) {
    console.error("Get stats error:", error);
    res.status(500).json({ message: "Failed to retrieve dashboard stats" });
  }
};
