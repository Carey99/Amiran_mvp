import { Request, Response } from "express";
import { storage } from "../storage";
import { z } from "zod";
import { insertInstructorSchema, insertUserSchema } from "@shared/schema";
import { hashPassword } from "../utils/passwordUtils";
import { sendEmail } from "../services/emailService";

// Get all instructors
export const getAllInstructors = async (req: Request, res: Response) => {
  try {
    const instructors = await storage.getAllInstructors();
    
    // For each instructor, get the associated user
    const enhancedInstructors = await Promise.all(instructors.map(async (instructor) => {
      const user = await storage.getUser(instructor.userId);
      return {
        ...instructor,
        user: user ? { 
          id: user.id, 
          username: user.username, 
          name: user.name, 
          email: user.email, 
          role: user.role 
        } : null
      };
    }));
    
    res.status(200).json(enhancedInstructors);
  } catch (error) {
    console.error("Get all instructors error:", error);
    res.status(500).json({ message: "Failed to retrieve instructors" });
  }
};

// Add a new instructor
export const addInstructor = async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = insertInstructorSchema.omit({ userId: true }).parse(req.body);
    
    // Create a username from the email
    const email = validatedData.email;
    const username = email.split('@')[0];
    
    // Generate a random password
    const tempPassword = Math.random().toString(36).slice(-8);
    
    // Create user first
    const userData = {
      username,
      password: await hashPassword(tempPassword),
      name: validatedData.fullName,
      email: validatedData.email,
      phone: validatedData.phone,
      role: "instructor" as const
    };
    
    const user = await storage.createUser(userData);
    
    // Then create instructor
    const instructorData = {
      ...validatedData,
      userId: user.id
    };
    
    const instructor = await storage.createInstructor(instructorData);
    
    // Send welcome email with credentials
    await sendEmail({
      to: instructor.email,
      subject: "Welcome to Amiran Driving School - Your Instructor Account",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e5e5e5; border-radius: 5px;">
          <h2 style="color: #2563eb;">Welcome to Amiran Driving School!</h2>
          <p>Hello ${instructor.fullName},</p>
          <p>You have been registered as an instructor at Amiran Driving School. Below are your login credentials:</p>
          <p><strong>Username:</strong> ${username}</p>
          <p><strong>Temporary Password:</strong> ${tempPassword}</p>
          <p>Please change your password after your first login for security reasons.</p>
          <p>You can access the system at: <a href="https://amiran-driving-school.co.ke">https://amiran-driving-school.co.ke</a></p>
          <p>If you have any questions, please contact the administrator.</p>
          <p>Best regards,<br/>The Amiran Team</p>
        </div>
      `
    });
    
    // Return the instructor without sensitive information
    res.status(201).json({
      ...instructor,
      user: {
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: error.errors 
      });
    }
    console.error("Add instructor error:", error);
    res.status(500).json({ message: "Failed to add instructor" });
  }
};

// Get instructor dashboard data
export const getInstructorDashboard = async (req: Request, res: Response) => {
  try {
    // Get instructor profile using the user ID from the session
    const instructorUser = req.user;
    if (!instructorUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const instructor = await storage.getInstructorByUserId(instructorUser.id);
    if (!instructor) {
      return res.status(404).json({ message: "Instructor profile not found" });
    }
    
    // Get active students for this instructor
    const students = await storage.getStudentsByInstructorId(instructor.id);
    
    // Enhance students with completed lessons
    const activeStudents = await Promise.all(students.map(async (student) => {
      const completedLessons = await storage.getLessonsByStudentId(student.id);
      return {
        ...student,
        completedLessons
      };
    }));
    
    // Get recent and upcoming lessons
    const recentLessons = await storage.getRecentLessonsByInstructorId(instructor.id);
    const upcomingLessons = await storage.getUpcomingLessonsByInstructorId(instructor.id);
    
    // Enhance lessons with student names
    const enhancedRecentLessons = await Promise.all(recentLessons.map(async (lesson) => {
      const student = await storage.getStudentById(lesson.studentId);
      return {
        ...lesson,
        studentName: student?.fullName || "Unknown Student",
        studentId: student?.id
      };
    }));
    
    const enhancedUpcomingLessons = await Promise.all(upcomingLessons.map(async (lesson) => {
      const student = await storage.getStudentById(lesson.studentId);
      return {
        ...lesson,
        studentName: student?.fullName || "Unknown Student",
        studentId: student?.id,
        // For demo purposes, let's add a time
        time: `${Math.floor(Math.random() * 12) + 8}:00 ${Math.random() > 0.5 ? 'AM' : 'PM'}`
      };
    }));
    
    // Return dashboard data
    res.status(200).json({
      instructor: {
        id: instructor.id,
        name: instructorUser.name,
        email: instructor.email,
        phone: instructor.phone,
        specialization: instructor.specialization,
        experience: instructor.experience
      },
      activeStudents,
      recentLessons: enhancedRecentLessons,
      upcomingLessons: enhancedUpcomingLessons
    });
  } catch (error) {
    console.error("Get instructor dashboard error:", error);
    res.status(500).json({ message: "Failed to retrieve instructor dashboard" });
  }
};
