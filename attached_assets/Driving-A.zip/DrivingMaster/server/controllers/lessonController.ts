import { Request, Response } from "express";
import { storage } from "../storage";
import { z } from "zod";
import { generateLessonReceipt } from "../services/receiptService";
import { sendLessonCompletionNotification } from "../services/emailService";

// Add a new lesson
export const addLesson = async (req: Request, res: Response) => {
  try {
    const studentId = parseInt(req.params.id);
    if (isNaN(studentId)) {
      return res.status(400).json({ message: "Invalid student ID" });
    }
    
    // Get student
    const student = await storage.getStudentById(studentId);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }
    
    // Check if student has an outstanding balance (only enforce after lesson 13)
    const completedLessons = await storage.getLessonsByStudentId(studentId);
    if (completedLessons.length >= 13 && student.balance > 0) {
      return res.status(403).json({ 
        message: "Cannot add more lessons. Student has completed 13 lessons and has an outstanding balance." 
      });
    }
    
    // Check if student has already reached maximum lessons
    if (completedLessons.length >= student.totalLessons) {
      return res.status(400).json({ 
        message: `Student has already completed the maximum number of lessons (${student.totalLessons})` 
      });
    }
    
    // Validate request body
    const lessonSchema = z.object({
      notes: z.string().optional()
    });
    
    const { notes } = lessonSchema.parse(req.body);
    
    // Get instructor from user
    const instructorUser = req.user;
    if (!instructorUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    let instructorId;
    if (instructorUser.role === 'instructor') {
      const instructor = await storage.getInstructorByUserId(instructorUser.id);
      if (!instructor) {
        return res.status(404).json({ message: "Instructor profile not found" });
      }
      instructorId = instructor.id;
    } else {
      // For admins, use a default instructor
      const instructors = await storage.getAllInstructors();
      if (instructors.length === 0) {
        return res.status(500).json({ message: "No instructors available" });
      }
      instructorId = instructors[0].id;
    }
    
    // Create lesson
    const newLesson = await storage.createLesson({
      studentId,
      instructorId,
      lessonNumber: completedLessons.length + 1,
      notes: notes || "",
      completed: true
    });
    
    // Update student if all lessons are completed
    if (completedLessons.length + 1 === student.totalLessons) {
      // In a real system, we would update student status to 'completed'
      // For this mock, we'll just log it
      console.log(`Student ${student.fullName} has completed all lessons`);
    }
    
    // Get instructor for the response
    const instructor = await storage.getInstructorById(instructorId);
    
    // Send lesson completion notification
    await sendLessonCompletionNotification(
      student.email,
      student.fullName,
      newLesson.lessonNumber
    );
    
    res.status(201).json({
      ...newLesson,
      instructor: instructor ? instructor.fullName : "Unknown Instructor"
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: error.errors 
      });
    }
    console.error("Add lesson error:", error);
    res.status(500).json({ message: "Failed to add lesson" });
  }
};

// Generate a receipt for a completed lesson
export const generateReceipt = async (req: Request, res: Response) => {
  try {
    const lessonId = parseInt(req.params.lessonId);
    if (isNaN(lessonId)) {
      return res.status(400).json({ message: "Invalid lesson ID" });
    }
    
    // Generate receipt HTML
    const receiptHtml = await generateLessonReceipt(lessonId);
    
    res.setHeader('Content-Type', 'text/html');
    res.send(receiptHtml);
  } catch (error) {
    console.error("Generate receipt error:", error);
    res.status(500).json({ message: "Failed to generate receipt" });
  }
};
