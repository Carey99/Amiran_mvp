import { Request, Response } from 'express';
import { storage } from '../storage';
import { initiateMpesaPayment, queryTransactionStatus } from '../middlewares/mpesa';
import { z } from 'zod';

// Payment initiation validation schema
const paymentInitSchema = z.object({
  studentId: z.number(),
  amount: z.number().positive(),
  method: z.enum(['mpesa', 'bank', 'cash', 'other']),
  phone: z.string().optional(),
});

// Payment confirmation validation schema
const paymentConfirmSchema = z.object({
  paymentId: z.number(),
  transactionId: z.string().optional(),
  status: z.enum(['completed', 'failed']),
});

/**
 * Initiates a payment request
 */
export const initiatePayment = async (req: Request, res: Response) => {
  try {
    // Validate request data
    const validatedData = paymentInitSchema.parse(req.body);
    const { studentId, amount, method, phone } = validatedData;

    // Get student to verify they exist
    const student = await storage.getStudentById(studentId);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student not found' });
    }

    // Different handling based on payment method
    let paymentResponse;
    let initialStatus = 'pending';

    if (method === 'mpesa') {
      // For M-Pesa, we initiate the STK push
      if (!phone && !student.phone) {
        return res.status(400).json({ success: false, message: 'Phone number is required for M-Pesa payment' });
      }

      const phoneToUse = phone || student.phone;
      const accountRef = `ADS-${studentId}-${Date.now().toString().substring(8, 13)}`;
      
      // Initiate M-Pesa payment
      const mpesaResponse = await initiateMpesaPayment(phoneToUse, amount, accountRef);
      
      if (!mpesaResponse.success) {
        return res.status(400).json({ 
          success: false, 
          message: 'Failed to initiate M-Pesa payment',
          error: mpesaResponse.message
        });
      }

      paymentResponse = {
        checkoutRequestId: mpesaResponse.checkoutRequestId,
        message: 'Payment request sent to your phone. Please complete the payment.'
      };
    } else if (method === 'cash') {
      // Cash payments are considered completed immediately
      initialStatus = 'completed';
      paymentResponse = {
        message: 'Cash payment recorded successfully'
      };
    } else {
      // Bank or other payments start as pending
      paymentResponse = {
        message: 'Payment recorded successfully. Waiting for confirmation.'
      };
    }

    // Create payment record
    const payment = await storage.createPayment({
      studentId,
      amount,
      method,
      status: initialStatus as any,
      date: new Date(),
      transactionId: paymentResponse.checkoutRequestId || null,
      metadata: {} // Will store additional details if needed
    });

    // If cash payment, update student balance immediately
    if (method === 'cash') {
      await storage.updateStudentBalance(studentId, amount);
    }

    return res.status(200).json({
      success: true,
      payment,
      ...paymentResponse
    });

  } catch (error: any) {
    console.error('Payment initiation error:', error);
    
    if (error.name === 'ZodError') {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid payment data',
        errors: error.errors 
      });
    }
    
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to process payment request',
      error: error.message
    });
  }
};

/**
 * Handles M-Pesa callback
 */
export const handlePaymentCallback = async (req: Request, res: Response) => {
  try {
    // The M-Pesa callback middleware will have already processed the callback
    // and added the result to req.mpesaCallback
    if (!req.mpesaCallback) {
      return res.status(400).json({ success: false, message: 'Invalid callback data' });
    }

    const { success, message, data } = req.mpesaCallback;

    if (!success || !data) {
      // Log the failure but don't return an error to M-Pesa
      console.error('M-Pesa callback failed:', message);
      return res.status(200).json({ ResultCode: 0, ResultDesc: 'Callback received' });
    }

    // Find the payment record using the checkout request ID
    const payments = await storage.getAllPayments();
    const payment = payments.find(p => p.transactionId === data.checkoutRequestId);

    if (!payment) {
      console.error('Payment not found for checkout request:', data.checkoutRequestId);
      return res.status(200).json({ ResultCode: 0, ResultDesc: 'Callback received' });
    }

    // Update the payment status
    await storage.updatePaymentStatus(payment.id, 'completed', data.mpesaReceiptNumber);

    // Update student balance
    await storage.updateStudentBalance(payment.studentId, payment.amount);

    console.log('Payment completed successfully:', data.mpesaReceiptNumber);

    // Always respond with success to M-Pesa
    return res.status(200).json({ ResultCode: 0, ResultDesc: 'Callback processed successfully' });

  } catch (error: any) {
    console.error('M-Pesa callback processing error:', error);
    
    // Always send success response to M-Pesa regardless of our processing errors
    return res.status(200).json({ ResultCode: 0, ResultDesc: 'Callback received' });
  }
};

/**
 * Manually confirms a payment (for bank transfers, etc.)
 */
export const confirmPayment = async (req: Request, res: Response) => {
  try {
    // Validate request data
    const validatedData = paymentConfirmSchema.parse(req.body);
    const { paymentId, transactionId, status } = validatedData;

    // Get the payment
    const payment = await storage.getPaymentById(paymentId);
    if (!payment) {
      return res.status(404).json({ success: false, message: 'Payment not found' });
    }

    // If payment is already in the desired status, just return it
    if (payment.status === status) {
      return res.status(200).json({ success: true, payment, message: 'Payment already updated' });
    }

    // Update payment status
    const updatedPayment = await storage.updatePaymentStatus(paymentId, status, transactionId || payment.transactionId);

    // If marked as completed, update student balance
    if (status === 'completed') {
      await storage.updateStudentBalance(payment.studentId, payment.amount);
    }

    return res.status(200).json({
      success: true,
      payment: updatedPayment,
      message: status === 'completed' ? 'Payment confirmed successfully' : 'Payment marked as failed'
    });

  } catch (error: any) {
    console.error('Payment confirmation error:', error);
    
    if (error.name === 'ZodError') {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid confirmation data',
        errors: error.errors 
      });
    }
    
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to confirm payment',
      error: error.message
    });
  }
};

/**
 * Get recent payments for dashboard
 */
export const getRecentPayments = async (req: Request, res: Response) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
    const payments = await storage.getRecentPayments(limit);
    
    return res.status(200).json({
      success: true,
      payments
    });
  } catch (error: any) {
    console.error('Get recent payments error:', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch recent payments',
      error: error.message
    });
  }
};

/**
 * Generate payment reports (summary by date range, method, etc.)
 */
export const generateReport = async (req: Request, res: Response) => {
  try {
    // This would be expanded with proper filtering by date range, payment methods, etc.
    const allPayments = await storage.getAllPayments();
    const completedPayments = allPayments.filter(p => p.status === 'completed');
    
    // Simple report example
    const report = {
      totalPayments: completedPayments.length,
      totalAmount: completedPayments.reduce((sum, p) => sum + p.amount, 0),
      byMethod: {
        mpesa: completedPayments.filter(p => p.method === 'mpesa').length,
        cash: completedPayments.filter(p => p.method === 'cash').length,
        bank: completedPayments.filter(p => p.method === 'bank').length,
        other: completedPayments.filter(p => p.method === 'other').length,
      },
      byMethodAmount: {
        mpesa: completedPayments.filter(p => p.method === 'mpesa').reduce((sum, p) => sum + p.amount, 0),
        cash: completedPayments.filter(p => p.method === 'cash').reduce((sum, p) => sum + p.amount, 0),
        bank: completedPayments.filter(p => p.method === 'bank').reduce((sum, p) => sum + p.amount, 0),
        other: completedPayments.filter(p => p.method === 'other').reduce((sum, p) => sum + p.amount, 0),
      }
    };
    
    return res.status(200).json({
      success: true,
      report
    });
  } catch (error: any) {
    console.error('Generate payment report error:', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to generate payment report',
      error: error.message
    });
  }
};