import { Request, Response } from "express";
import { storage } from "../storage";
import { z } from "zod";
import { insertStudentSchema } from "@shared/schema";
import { sendEmail } from "../services/emailService";
import { calculateTotalFee as getCourseTypeDefaultFee, getLessonCount as getDefaultLessonsForCourse, formatCourseType, formatBranch } from "../utils/courseUtils";

// Get all students
export const getAllStudents = async (req: Request, res: Response) => {
  try {
    const students = await storage.getAllStudents();
    
    // For each student, get completed lessons and payments
    const enhancedStudents = await Promise.all(students.map(async (student) => {
      const completedLessons = await storage.getLessonsByStudentId(student.id);
      const payments = await storage.getPaymentsByStudentId(student.id);
      return {
        ...student,
        completedLessons,
        payments
      };
    }));
    res.status(200).json(enhancedStudents);
  } catch (error) {
    console.error("Get all students error:", error);
    res.status(500).json({ message: "Failed to retrieve students" });
  }
};

// Get current students (active and with balance)
export const getCurrentStudents = async (req: Request, res: Response) => {
  try {
    const students = await storage.getCurrentStudents();
    // For each student, get completed lessons and payments
    const enhancedStudents = await Promise.all(students.map(async (student) => {
      const completedLessons = await storage.getLessonsByStudentId(student.id);
      const payments = await storage.getPaymentsByStudentId(student.id);
      return {
        ...student,
        completedLessons,
        payments
      };
    }));
    res.status(200).json(enhancedStudents);
  } catch (error) {
    console.error("Get current students error:", error);
    res.status(500).json({ message: "Failed to retrieve current students" });
  }
};

// Get concluded students
export const getConcludedStudents = async (req: Request, res: Response) => {
  try {
    const students = await storage.getConcludedStudents();
    // For each student, get completed lessons and payments
    const enhancedStudents = await Promise.all(students.map(async (student) => {
      const completedLessons = await storage.getLessonsByStudentId(student.id);
      const payments = await storage.getPaymentsByStudentId(student.id);
      return {
        ...student,
        completedLessons,
        payments
      };
    }));
    res.status(200).json(enhancedStudents);
  } catch (error) {
    console.error("Get concluded students error:", error);
    res.status(500).json({ message: "Failed to retrieve concluded students" });
  }
};

// Get recent students
export const getRecentStudents = async (req: Request, res: Response) => {
  try {
    const students = await storage.getRecentStudents();
    res.status(200).json(students); // Simplified response - no need for enhancedStudents here as per edited code.
  } catch (error) {
    console.error("Get recent students error:", error);
    res.status(500).json({ message: "Failed to retrieve recent students" });
  }
};

// Get student by ID
export const getStudentById = async (req: Request, res: Response) => {
  try {
    const studentId = parseInt(req.params.id);
    if (isNaN(studentId)) {
      return res.status(400).json({ message: "Invalid student ID" });
    }
    const student = await storage.getStudentById(studentId);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }
    // Get completed lessons and payments
    const completedLessons = await storage.getLessonsByStudentId(student.id);
    const payments = await storage.getPaymentsByStudentId(student.id);
    const enhancedStudent = {
      ...student,
      completedLessons,
      payments
    };
    res.status(200).json(enhancedStudent);
  } catch (error) {
    console.error("Get student by ID error:", error);
    res.status(500).json({ message: "Failed to retrieve student" });
  }
};

// Register a new student
export const registerStudent = async (req: Request, res: Response) => {
  try {

    // Logging the incoming request body
    console.log("registerStudent invoked with data:", req.body);

    const validatedData = insertStudentSchema.parse(req.body);
    // Set default values for new student
    const courseFee = getCourseTypeDefaultFee(validatedData.courseType);
    const studentData = {
      ...validatedData,
      status: "pending" as const,
      balance: courseFee,
      courseFee,
      totalLessons: getDefaultLessonsForCourse(validatedData.courseType),
      registrationDate: new Date(),
      lessonsCompleted: 0
    };
    //storing the student data
    const student = await storage.createStudent(studentData);
    // Send welcome email
    await sendEmail({
      to: student.email,
      subject: "Welcome to Amiran Driving School",
      html: `
        <div>
          <h2>Welcome to Amiran Driving School!</h2>
          <p>Hello ${student.fullName},</p>
          <p>Thank you for registering with Amiran Driving School.</p>
          <p><strong>Course Details:</strong> ${formatCourseType(student.courseType)}</p>
          <p><strong>Branch:</strong> ${formatBranch(student.branch)}</p>
          <p><strong>Course Fee:</strong> KES ${student.courseFee.toLocaleString()}</p>
        </div>
      `
    });
    res.status(201).json(student);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        message: "Validation error",
        errors: error.errors
      });
    }
    console.error("Register student error:", error);
    res.status(500).json({ message: "Failed to register student" });
  }
};

// Adjust student balance (for super admins only)
export const adjustStudentBalance = async (req: Request, res: Response) => {
  try {
    const studentId = parseInt(req.params.id);
    if (isNaN(studentId)) {
      return res.status(400).json({ message: "Invalid student ID" });
    }
    const adjustmentSchema = z.object({
      adjustment: z.number()
    });
    const { adjustment } = adjustmentSchema.parse(req.body);
    const student = await storage.getStudentById(studentId);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }
    const updatedStudent = await storage.updateStudentBalance(studentId, adjustment);
    if (!updatedStudent) {
      return res.status(500).json({ message: "Failed to update student balance" });
    }
    // Get completed lessons and payments
    const completedLessons = await storage.getLessonsByStudentId(updatedStudent.id);
    const payments = await storage.getPaymentsByStudentId(updatedStudent.id);
    const enhancedStudent = {
      ...updatedStudent,
      completedLessons,
      payments
    };
    // Send notification if it's a discount
    if (adjustment < 0) {
      await sendEmail({
        to: student.email,
        subject: "Discount Applied to Your Account",
        html: `
          <div>
            <h2>Discount Applied</h2>
            <p>Hello ${student.fullName},</p>
            <p>We are pleased to inform you that a discount of <strong>KES ${Math.abs(adjustment).toLocaleString()}</strong> has been applied to your account.</p>
            <p>Your new balance is <strong>KES ${updatedStudent.balance.toLocaleString()}</strong>.</p>
            <p>Thank you for choosing Amiran Driving School.</p>
            <p>Best regards,<br/>The Amiran Team</p>
          </div>
        `
      });
    }
    res.status(200).json(enhancedStudent);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        message: "Validation error",
        errors: error.errors
      });
    }
    console.error("Adjust student balance error:", error);
    res.status(500).json({ message: "Failed to adjust student balance" });
  }
};

// Helper functions (moved to utils/courseUtils.ts in the edited code)
// These functions are assumed to exist in utils/courseUtils.ts