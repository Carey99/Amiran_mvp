import mongoose from 'mongoose';
import { IStorage } from '../storage';
import {
  UserModel, StudentModel, InstructorModel, LessonModel, PaymentModel,
  UserDocument, StudentDocument, InstructorDocument, LessonDocument, PaymentDocument
} from './models';
import connectDB from './mongoose';
import { comparePassword } from '../utils/passwordUtils';
import {
  User as UserType, Student as StudentType, Instructor as InstructorType,
  Lesson as LessonType, Payment as PaymentType,
  InsertUser, InsertStudent, InsertInstructor, InsertLesson, InsertPayment
} from '@shared/schema';
import { startOfToday, startOfMonth, endOfMonth } from 'date-fns';

/**
 * Helper function to convert document objects to the expected type
 */
function convertToType<T>(doc: any): T {
  // Convert Mongoose document to plain object and ensure _id is transformed to id
  const obj = doc.toObject ? doc.toObject() : doc;
  
  // If the document has an _id field, copy it to id
  if (obj._id !== undefined && obj.id === undefined) {
    obj.id = obj._id;
  }
  
  // Remove MongoDB specific fields
  delete obj._id;
  delete obj.__v;
  
  return obj as T;
}

/**
 * MongoDB Storage implementation of the IStorage interface
 */
export class MongoStorage implements IStorage {
  constructor() {
    // Ensure MongoDB is connected
    connectDB().catch(err => {
      console.error('Failed to connect to MongoDB:', err);
    });
  }

  // User methods
  async getUser(id: number): Promise<UserType | undefined> {
    try {
      const user = await UserModel.findOne({ id });
      return user ? convertToType<UserType>(user) : undefined;
    } catch (error) {
      console.error('MongoStorage getUser error:', error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<UserType | undefined> {
    try {
      const user = await UserModel.findOne({ username });
      return user ? convertToType<UserType>(user) : undefined;
    } catch (error) {
      console.error('MongoStorage getUserByUsername error:', error);
      return undefined;
    }
  }

  async createUser(user: InsertUser): Promise<UserType> {
    try {
      // Find highest existing ID
      const highestUser = await UserModel.findOne().sort({ id: -1 });
      const newId = highestUser ? (highestUser.id as number) + 1 : 1;
      
      const newUser = new UserModel({
        ...user,
        id: newId,
        createdAt: new Date()
      });
      
      await newUser.save();
      return convertToType<UserType>(newUser);
    } catch (error) {
      console.error('MongoStorage createUser error:', error);
      throw error;
    }
  }

  async validateUserCredentials(username: string, password: string): Promise<UserType | null> {
    try {
      const user = await UserModel.findOne({ username });
      if (!user) {
        return null;
      }

      const isMatch = await user.comparePassword(password);
      return isMatch ? convertToType<UserType>(user) : null;
    } catch (error) {
      console.error('MongoStorage validateUserCredentials error:', error);
      return null;
    }
  }

  // Student methods
  async getAllStudents(): Promise<StudentType[]> {
    try {
      const students = await StudentModel.find().sort({ registrationDate: -1 });
      return students.map(student => convertToType<StudentType>(student));
    } catch (error) {
      console.error('MongoStorage getAllStudents error:', error);
      return [];
    }
  }

  async getCurrentStudents(): Promise<StudentType[]> {
    try {
      const students = await StudentModel.find({ status: 'active' }).sort({ registrationDate: -1 });
      return students.map(student => convertToType<StudentType>(student));
    } catch (error) {
      console.error('MongoStorage getCurrentStudents error:', error);
      return [];
    }
  }

  async getConcludedStudents(): Promise<StudentType[]> {
    try {
      const students = await StudentModel.find({ status: 'completed' }).sort({ registrationDate: -1 });
      return students.map(student => convertToType<StudentType>(student));
    } catch (error) {
      console.error('MongoStorage getConcludedStudents error:', error);
      return [];
    }
  }

  async getRecentStudents(limit: number = 5): Promise<StudentType[]> {
    try {
      const students = await StudentModel.find().sort({ registrationDate: -1 }).limit(limit);
      return students.map(student => convertToType<StudentType>(student));
    } catch (error) {
      console.error('MongoStorage getRecentStudents error:', error);
      return [];
    }
  }

  async getStudentById(id: number): Promise<StudentType | undefined> {
    try {
      const student = await StudentModel.findOne({ id });
      return student ? convertToType<StudentType>(student) : undefined;
    } catch (error) {
      console.error('MongoStorage getStudentById error:', error);
      return undefined;
    }
  }

  async createStudent(student: InsertStudent): Promise<StudentType> {
    try {
      // Find highest existing ID
      const highestStudent = await StudentModel.findOne().sort({ id: -1 });
      const newId = highestStudent ? (highestStudent.id as number) + 1 : 1;
      
      const newStudent = new StudentModel({
        ...student,
        id: newId,
        registrationDate: new Date(),
        createdAt: new Date()
      });
      
      await newStudent.save();
      return convertToType<StudentType>(newStudent);
    } catch (error) {
      console.error('MongoStorage createStudent error:', error);
      throw error;
    }
  }

  async updateStudentBalance(id: number, adjustment: number): Promise<StudentType | undefined> {
    try {
      const student = await StudentModel.findOne({ id });
      if (!student) {
        return undefined;
      }
      
      student.balance = (student.balance || 0) - adjustment;
      await student.save();
      
      return convertToType<StudentType>(student);
    } catch (error) {
      console.error('MongoStorage updateStudentBalance error:', error);
      return undefined;
    }
  }

  async getStudentsByInstructorId(instructorId: number): Promise<StudentType[]> {
    try {
      const students = await StudentModel.find({ instructorId });
      return students.map(student => convertToType<StudentType>(student));
    } catch (error) {
      console.error('MongoStorage getStudentsByInstructorId error:', error);
      return [];
    }
  }

  // Instructor methods
  async getAllInstructors(): Promise<InstructorType[]> {
    try {
      const instructors = await InstructorModel.find().sort({ createdAt: -1 });
      return instructors.map(instructor => convertToType<InstructorType>(instructor));
    } catch (error) {
      console.error('MongoStorage getAllInstructors error:', error);
      return [];
    }
  }

  async getInstructorById(id: number): Promise<InstructorType | undefined> {
    try {
      const instructor = await InstructorModel.findOne({ id });
      return instructor ? convertToType<InstructorType>(instructor) : undefined;
    } catch (error) {
      console.error('MongoStorage getInstructorById error:', error);
      return undefined;
    }
  }

  async getInstructorByUserId(userId: number | string | mongoose.Types.ObjectId): Promise<InstructorType | undefined> {
    try {
      // Convert userId to ObjectId if it's a string
      let searchId: any = userId;
      if (typeof userId === 'string' && mongoose.Types.ObjectId.isValid(userId)) {
        searchId = new mongoose.Types.ObjectId(userId);
      } else if (typeof userId === 'number') {
        // If we're looking up by numeric ID, try to find the user first
        const user = await UserModel.findOne({ id: userId });
        if (user) {
          searchId = user._id;
        }
      }
      
      const instructor = await InstructorModel.findOne({ userId: searchId });
      return instructor ? convertToType<InstructorType>(instructor) : undefined;
    } catch (error) {
      console.error('MongoStorage getInstructorByUserId error:', error);
      return undefined;
    }
  }

  async createInstructor(instructor: InsertInstructor): Promise<InstructorType> {
    try {
      // Find highest existing ID
      const highestInstructor = await InstructorModel.findOne().sort({ id: -1 });
      const newId = highestInstructor ? (highestInstructor.id as number) + 1 : 1;
      
      const newInstructor = new InstructorModel({
        ...instructor,
        id: newId,
        active: true,
        createdAt: new Date()
      });
      
      await newInstructor.save();
      return convertToType<InstructorType>(newInstructor);
    } catch (error) {
      console.error('MongoStorage createInstructor error:', error);
      throw error;
    }
  }

  // Lesson methods
  async getLessonById(id: number): Promise<LessonType | undefined> {
    try {
      const lesson = await LessonModel.findOne({ id });
      return lesson ? convertToType<LessonType>(lesson) : undefined;
    } catch (error) {
      console.error('MongoStorage getLessonById error:', error);
      return undefined;
    }
  }

  async getLessonsByStudentId(studentId: number): Promise<LessonType[]> {
    try {
      const lessons = await LessonModel.find({ studentId }).sort({ date: 1 });
      return lessons.map(lesson => convertToType<LessonType>(lesson));
    } catch (error) {
      console.error('MongoStorage getLessonsByStudentId error:', error);
      return [];
    }
  }

  async getRecentLessonsByInstructorId(instructorId: number): Promise<LessonType[]> {
    try {
      const today = new Date();
      const lessons = await LessonModel.find({
        instructorId,
        date: { $lte: today },
        completed: true
      }).sort({ date: -1 }).limit(5);
      
      return lessons.map(lesson => convertToType<LessonType>(lesson));
    } catch (error) {
      console.error('MongoStorage getRecentLessonsByInstructorId error:', error);
      return [];
    }
  }

  async getUpcomingLessonsByInstructorId(instructorId: number): Promise<LessonType[]> {
    try {
      const today = new Date();
      const lessons = await LessonModel.find({
        instructorId,
        date: { $gt: today }
      }).sort({ date: 1 });
      
      return lessons.map(lesson => convertToType<LessonType>(lesson));
    } catch (error) {
      console.error('MongoStorage getUpcomingLessonsByInstructorId error:', error);
      return [];
    }
  }

  async createLesson(lesson: InsertLesson): Promise<LessonType> {
    try {
      // Find highest existing ID
      const highestLesson = await LessonModel.findOne().sort({ id: -1 });
      const newId = highestLesson ? (highestLesson.id as number) + 1 : 1;
      
      const newLesson = new LessonModel({
        ...lesson,
        id: newId,
        completed: lesson.completed || false,
        date: lesson.date || new Date(),
        createdAt: new Date()
      });
      
      await newLesson.save();
      
      // Update student's lessonsCompleted count if this lesson is completed
      if (newLesson.completed) {
        await StudentModel.updateOne(
          { id: lesson.studentId },
          { $inc: { lessonsCompleted: 1 } }
        );
      }
      
      return convertToType<LessonType>(newLesson);
    } catch (error) {
      console.error('MongoStorage createLesson error:', error);
      throw error;
    }
  }

  async getTotalLessonsCompletedToday(): Promise<number> {
    try {
      const startOfTodayDate = startOfToday();
      const count = await LessonModel.countDocuments({
        date: { $gte: startOfTodayDate },
        completed: true
      });
      
      return count;
    } catch (error) {
      console.error('MongoStorage getTotalLessonsCompletedToday error:', error);
      return 0;
    }
  }

  // Payment methods
  async getPaymentById(id: number): Promise<PaymentType | undefined> {
    try {
      const payment = await PaymentModel.findOne({ id });
      return payment ? convertToType<PaymentType>(payment) : undefined;
    } catch (error) {
      console.error('MongoStorage getPaymentById error:', error);
      return undefined;
    }
  }

  async getPaymentsByStudentId(studentId: number): Promise<PaymentType[]> {
    try {
      const payments = await PaymentModel.find({ studentId }).sort({ date: -1 });
      return payments.map(payment => convertToType<PaymentType>(payment));
    } catch (error) {
      console.error('MongoStorage getPaymentsByStudentId error:', error);
      return [];
    }
  }

  async getAllPayments(): Promise<PaymentType[]> {
    try {
      const payments = await PaymentModel.find().sort({ date: -1 });
      return payments.map(payment => convertToType<PaymentType>(payment));
    } catch (error) {
      console.error('MongoStorage getAllPayments error:', error);
      return [];
    }
  }

  async createPayment(payment: InsertPayment): Promise<PaymentType> {
    try {
      // Find highest existing ID
      const highestPayment = await PaymentModel.findOne().sort({ id: -1 });
      const newId = highestPayment ? (highestPayment.id as number) + 1 : 1;
      
      // Generate receipt number if this is a completed payment
      const receiptNumber = payment.status === 'completed' 
        ? `ADS-${new Date().getFullYear()}-${newId.toString().padStart(5, '0')}`
        : null;
      
      const newPayment = new PaymentModel({
        ...payment,
        id: newId,
        receiptNumber,
        date: payment.date || new Date(),
        createdAt: new Date()
      });
      
      await newPayment.save();
      return convertToType<PaymentType>(newPayment);
    } catch (error) {
      console.error('MongoStorage createPayment error:', error);
      throw error;
    }
  }

  async updatePaymentStatus(id: number, status: string, transactionId?: string): Promise<PaymentType | undefined> {
    try {
      const payment = await PaymentModel.findOne({ id });
      if (!payment) {
        return undefined;
      }
      
      payment.status = status as any;
      
      if (transactionId) {
        payment.transactionId = transactionId;
      }
      
      // Generate receipt number if transitioning to completed
      if (status === 'completed' && !payment.receiptNumber) {
        payment.receiptNumber = `ADS-${new Date().getFullYear()}-${id.toString().padStart(5, '0')}`;
      }
      
      await payment.save();
      return convertToType<PaymentType>(payment);
    } catch (error) {
      console.error('MongoStorage updatePaymentStatus error:', error);
      return undefined;
    }
  }

  async getRecentPayments(limit: number = 5): Promise<PaymentType[]> {
    try {
      const payments = await PaymentModel.find().sort({ date: -1 }).limit(limit);
      return payments.map(payment => convertToType<PaymentType>(payment));
    } catch (error) {
      console.error('MongoStorage getRecentPayments error:', error);
      return [];
    }
  }

  async getTodayTotalPayments(): Promise<number> {
    try {
      const startOfTodayDate = startOfToday();
      const result = await PaymentModel.aggregate([
        {
          $match: {
            date: { $gte: startOfTodayDate },
            status: 'completed'
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$amount' }
          }
        }
      ]);
      
      return result.length > 0 ? result[0].total : 0;
    } catch (error) {
      console.error('MongoStorage getTodayTotalPayments error:', error);
      return 0;
    }
  }

  // Stats methods
  async getTotalStudentsCount(): Promise<number> {
    try {
      return await StudentModel.countDocuments();
    } catch (error) {
      console.error('MongoStorage getTotalStudentsCount error:', error);
      return 0;
    }
  }

  async getCurrentStudentsCount(): Promise<number> {
    try {
      return await StudentModel.countDocuments({ status: 'active' });
    } catch (error) {
      console.error('MongoStorage getCurrentStudentsCount error:', error);
      return 0;
    }
  }

  async getMonthlyRevenue(): Promise<number> {
    try {
      const startMonth = startOfMonth(new Date());
      const endMonth = endOfMonth(new Date());
      
      const result = await PaymentModel.aggregate([
        {
          $match: {
            date: { $gte: startMonth, $lte: endMonth },
            status: 'completed'
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$amount' }
          }
        }
      ]);
      
      return result.length > 0 ? result[0].total : 0;
    } catch (error) {
      console.error('MongoStorage getMonthlyRevenue error:', error);
      return 0;
    }
  }

  async getPendingPaymentsTotal(): Promise<number> {
    try {
      const result = await StudentModel.aggregate([
        {
          $match: {
            balance: { $gt: 0 }
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$balance' }
          }
        }
      ]);
      
      return result.length > 0 ? result[0].total : 0;
    } catch (error) {
      console.error('MongoStorage getPendingPaymentsTotal error:', error);
      return 0;
    }
  }

  async getTodayRegistrationsCount(): Promise<number> {
    try {
      const startOfTodayDate = startOfToday();
      return await StudentModel.countDocuments({ registrationDate: { $gte: startOfTodayDate } });
    } catch (error) {
      console.error('MongoStorage getTodayRegistrationsCount error:', error);
      return 0;
    }
  }

  async getPaymentRemindersCount(): Promise<number> {
    try {
      return await StudentModel.countDocuments({ 
        status: 'active',
        balance: { $gt: 0 }
      });
    } catch (error) {
      console.error('MongoStorage getPaymentRemindersCount error:', error);
      return 0;
    }
  }
}