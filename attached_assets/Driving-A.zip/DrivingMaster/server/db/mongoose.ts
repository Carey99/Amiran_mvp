import mongoose from 'mongoose';
import { seedDatabase } from './seed';
import dotenv from 'dotenv';
dotenv.config();

// Define a type for our cache
interface MongooseCache {
  conn: mongoose.Connection | null;
  promise: Promise<mongoose.Connection> | null;
}

// Define global type
declare global {
  var mongooseCache: MongooseCache;
}

// Initialize global cache
if (!global.mongooseCache) {
  global.mongooseCache = { conn: null, promise: null };
}

let cached = global.mongooseCache;

/**
 * Connect to MongoDB Atlas
 */
async function connectDB() {
  if (cached.conn) {
    return cached.conn;
  }

  if (!cached.promise) {
    const mongoUri = process.env.MONGODB_URI;

    if (!mongoUri) {
      throw new Error('MONGODB_URI environment variable not set');
    }

    const options = {
      bufferCommands: false,
    };

    cached.promise = mongoose.connect(mongoUri, options)
      .then(async (mongoose) => {
        console.log('Connected to MongoDB Atlas');
        
        // Seed database with initial data if needed
        await seedDatabase();
        
        return mongoose.connection;
      })
      .catch((error) => {
        console.error('MongoDB connection error:', error);
        cached.promise = null;
        throw error;
      });
  }

  cached.conn = await cached.promise;
  return cached.conn;
}

export default connectDB;