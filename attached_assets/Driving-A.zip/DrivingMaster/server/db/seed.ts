import { UserModel, StudentModel, InstructorModel, LessonModel, PaymentModel } from './models';
import { hashPassword } from '../utils/passwordUtils';
import { addDays, subDays } from 'date-fns';

/**
 * Seed the database with initial data
 */
export async function seedDatabase() {
  try {
    // Check if we already have users
    const usersCount = await UserModel.countDocuments();
    
    if (usersCount > 0) {
      console.log('Database already has data, skipping seed process');
      return;
    }
    
    console.log('Seeding database with initial data...');
    
    // Create default users
    const superAdminUser = await UserModel.create({
      id: 1,
      name: 'Super Admin',
      username: 'superadmin',
      password: await hashPassword('password123'),
      email: 'superadmin@amiran.com',
      phone: '+254700000001',
      role: 'super_admin',
      createdAt: new Date()
    });
    
    const adminUser = await UserModel.create({
      id: 2,
      name: 'Admin User',
      username: 'admin',
      password: await hashPassword('password123'),
      email: 'admin@amiran.com',
      phone: '+254700000002',
      role: 'admin',
      createdAt: new Date()
    });
    
    // Only admin users are created
    
    // Create students
    const student1 = await StudentModel.create({
      id: 1,
      fullName: 'Jane Doe',
      email: 'jane@example.com',
      phone: '+254711111111',
      idNumber: 'ID123456',
      address: 'Nairobi, Kenya',
      courseType: 'class-b-manual',
      branch: 'kahawa-sukari',
      status: 'active',
      instructorId: instructor.id,
      balance: 5000,
      totalLessons: 10,
      lessonsCompleted: 3,
      registrationDate: new Date(),
      comments: 'Fast learner',
      nextLessonDate: addDays(new Date(), 2),
      createdAt: new Date(),
      courseFee: 15000
    });
    
    const student2 = await StudentModel.create({
      id: 2,
      fullName: 'John Smith',
      email: 'john@example.com',
      phone: '+254722222222',
      idNumber: 'ID234567',
      address: 'Kiambu, Kenya',
      courseType: 'class-b-auto',
      branch: 'mwihoko',
      status: 'active',
      instructorId: instructor.id,
      balance: 8000,
      totalLessons: 8,
      lessonsCompleted: 1,
      registrationDate: new Date(),
      comments: null,
      nextLessonDate: addDays(new Date(), 1),
      createdAt: new Date(),
      courseFee: 12000
    });
    
    const student3 = await StudentModel.create({
      id: 3,
      fullName: 'Alice Johnson',
      email: 'alice@example.com',
      phone: '+254733333333',
      idNumber: 'ID345678',
      address: 'Thika, Kenya',
      courseType: 'defensive-driving',
      branch: 'kahawa-sukari',
      status: 'completed',
      instructorId: instructor.id,
      balance: 0,
      totalLessons: 5,
      lessonsCompleted: 5,
      registrationDate: subDays(new Date(), 30),
      comments: 'Completed course successfully',
      nextLessonDate: null,
      createdAt: subDays(new Date(), 30),
      courseFee: 10000
    });
    
    // Create lessons
    await LessonModel.create({
      id: 1,
      studentId: student1.id,
      instructorId: instructor.id,
      lessonNumber: 1,
      date: subDays(new Date(), 5),
      completed: true,
      notes: 'Introduced basic car controls',
      createdAt: subDays(new Date(), 6)
    });
    
    await LessonModel.create({
      id: 2,
      studentId: student1.id,
      instructorId: instructor.id,
      lessonNumber: 2,
      date: subDays(new Date(), 3),
      completed: true,
      notes: 'Practiced parking',
      createdAt: subDays(new Date(), 4)
    });
    
    await LessonModel.create({
      id: 3,
      studentId: student1.id,
      instructorId: instructor.id,
      lessonNumber: 3,
      date: subDays(new Date(), 1),
      completed: true,
      notes: 'Highway driving practice',
      createdAt: subDays(new Date(), 2)
    });
    
    // Create payments
    await PaymentModel.create({
      id: 1,
      studentId: student1.id,
      amount: 10000,
      method: 'mpesa',
      status: 'completed',
      transactionId: 'MPESA123456',
      date: subDays(new Date(), 7),
      metadata: { purpose: 'Initial payment', receiptNumber: 'RCP001' },
      receiptNumber: 'RCP001',
      createdAt: subDays(new Date(), 7)
    });
    
    await PaymentModel.create({
      id: 2,
      studentId: student2.id,
      amount: 4000,
      method: 'cash',
      status: 'completed',
      transactionId: null,
      date: subDays(new Date(), 3),
      metadata: { purpose: 'Initial payment', receiptNumber: 'RCP002' },
      receiptNumber: 'RCP002',
      createdAt: subDays(new Date(), 3)
    });
    
    console.log('Database seeding completed successfully');
    
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}