import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';
import { Session } from 'express-session';

// Extend the Express Request type with a user property
declare global {
    namespace Express {
        interface Request {
            user?: any;
        }
    }
}

// Extend the Session type to include our user ID
declare module 'express-session' {
    interface SessionData {
        userId?: number;
    }
}

/**
 * Middleware to check if a user is authenticated
 */
export const authMiddleware = async (req: Request, res: Response, next: NextFunction) => {
    try {
        // Check if there's a user in the session
        const userId = req.session?.userId;
        
        if (!userId) {
            return res.status(401).json({ message: 'Not authenticated' });
        }
        
        // Get the user from storage
        const user = await storage.getUser(userId);
        
        if (!user) {
            // Clear the invalid session
            req.session.destroy((err) => {
                if (err) {
                    console.error('Error destroying session:', err);
                }
            });
            return res.status(401).json({ message: 'Invalid session' });
        }
        
        // Add user to request
        req.user = {
            id: user.id,
            name: user.name,
            username: user.username,
            email: user.email,
            role: user.role
        };
        
        next();
    } catch (error) {
        console.error('Auth middleware error:', error);
        res.status(500).json({ message: 'Authentication error' });
    }
};

/**
 * Middleware factory to check if a user has a specific role
 * @param roles Array of roles that are allowed
 */
export const checkRole = (roles: string[]) => {
    return (req: Request, res: Response, next: NextFunction) => {
        // authMiddleware should be called before this middleware
        if (!req.user) {
            return res.status(401).json({ message: 'Not authenticated' });
        }
        
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        next();
    };
};