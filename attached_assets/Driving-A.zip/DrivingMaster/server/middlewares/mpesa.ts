import { Request, Response, NextFunction } from 'express';
import axios from 'axios';

declare global {
    namespace Express {
        interface Request {
            mpesaCallback?: {
                success: boolean;
                message: string;
                data: any;
            };
        }
    }
}

/**
 * Initiates M-Pesa STK push request
 * @param phoneNumber Customer phone number in format 254XXXXXXXXX
 * @param amount Amount to charge
 * @param accountReference Reference for the transaction
 */
export const initiateMpesaPayment = async (phoneNumber: string, amount: number, accountReference: string) => {
    try {
        // Format phone number if needed (remove + and ensure it starts with 254)
        phoneNumber = phoneNumber.replace('+', '');
        if (phoneNumber.startsWith('0')) {
            phoneNumber = '254' + phoneNumber.substring(1);
        } else if (!phoneNumber.startsWith('254')) {
            phoneNumber = '254' + phoneNumber;
        }

        // Get timestamp in format YYYYMMDDHHmmss
        const timestamp = new Date().toISOString().replace(/[-T:.Z]/g, '').substring(0, 14);
        
        // In a real implementation, we would:
        // 1. Get the access token using consumer key and secret
        // 2. Generate a password using shortcode, passkey and timestamp
        // 3. Make the actual API call to M-Pesa

        // Simulate M-Pesa API call 
        // This will be replaced with actual M-Pesa API when credentials are available
        const simulatedResponse = {
            CheckoutRequestID: 'ws_CO_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 7),
            ResponseCode: '0',
            ResponseDescription: 'Success. Request accepted for processing',
            CustomerMessage: 'Success. Request accepted for processing'
        };

        console.log('M-Pesa STK push initiated for', phoneNumber, 'amount:', amount, 'ref:', accountReference);

        // Return the checkout request ID which will be used to query status
        return {
            success: true,
            checkoutRequestId: simulatedResponse.CheckoutRequestID,
            message: simulatedResponse.CustomerMessage
        };

    } catch (error: any) {
        console.error('M-Pesa STK push error:', error.message);
        return {
            success: false,
            message: error.message || 'Failed to initiate payment'
        };
    }
};

/**
 * Middleware to validate M-Pesa callback
 */
export const validateMpesaCallback = (req: Request, res: Response, next: NextFunction) => {
    try {
        const callbackData = req.body;
        
        // Sample validation logic - would be replaced with actual validation
        // against M-Pesa expected format
        if (!callbackData || !callbackData.Body) {
            req.mpesaCallback = {
                success: false,
                message: 'Invalid callback data format',
                data: null
            };
            return next();
        }

        const result = callbackData.Body.stkCallback;
        const isSuccessful = result.ResultCode === 0;

        // Extract transaction details from the callback
        let transactionData = null;
        if (isSuccessful && result.CallbackMetadata && result.CallbackMetadata.Item) {
            const items = result.CallbackMetadata.Item;
            
            // Extract key details (amount, receipt number, transaction date, phone)
            const amount = items.find((item: any) => item.Name === 'Amount')?.Value || 0;
            const mpesaReceiptNumber = items.find((item: any) => item.Name === 'MpesaReceiptNumber')?.Value || '';
            const transactionDate = items.find((item: any) => item.Name === 'TransactionDate')?.Value || '';
            const phoneNumber = items.find((item: any) => item.Name === 'PhoneNumber')?.Value || '';
            
            transactionData = {
                amount,
                mpesaReceiptNumber,
                transactionDate,
                phoneNumber,
                checkoutRequestId: result.CheckoutRequestID
            };
        }

        req.mpesaCallback = {
            success: isSuccessful,
            message: isSuccessful ? 'Payment successful' : result.ResultDesc,
            data: transactionData
        };

        next();
    } catch (error: any) {
        req.mpesaCallback = {
            success: false,
            message: error.message || 'Failed to process callback',
            data: null
        };
        next();
    }
};

/**
 * Query the status of an M-Pesa transaction
 * @param transactionId The checkout request ID
 */
export const queryTransactionStatus = async (transactionId: string) => {
    try {
        // In a real implementation, we would:
        // 1. Get the access token
        // 2. Make the actual API call to M-Pesa's query endpoint

        // Simulate a query response
        // This will be replaced with actual M-Pesa API when credentials are available
        const simulatedResponse = {
            ResponseCode: '0',
            ResponseDescription: 'The service request has been accepted successfully',
            MerchantRequestID: 'merchant-' + Date.now(),
            CheckoutRequestID: transactionId,
            ResultCode: Math.random() > 0.3 ? '0' : '1032', // 70% success rate
            ResultDesc: Math.random() > 0.3 ? 'The transaction was successful' : 'Transaction cancelled by user'
        };

        const isSuccessful = simulatedResponse.ResultCode === '0';

        return {
            success: isSuccessful,
            message: simulatedResponse.ResultDesc,
            data: isSuccessful ? {
                transactionId,
                status: 'completed'
            } : {
                transactionId,
                status: 'failed'
            }
        };

    } catch (error: any) {
        console.error('M-Pesa query error:', error.message);
        return {
            success: false,
            message: error.message || 'Failed to query transaction status',
            data: {
                transactionId,
                status: 'unknown'
            }
        };
    }
};