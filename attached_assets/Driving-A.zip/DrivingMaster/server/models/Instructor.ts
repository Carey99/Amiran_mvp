import mongoose, { Document, Schema } from 'mongoose';

export interface InstructorDocument extends Document {
  fullName: string;
  email: string;
  phone: string;
  userId: mongoose.Types.ObjectId | string;
  specialization: 'class-a' | 'class-b-manual' | 'class-b-auto' | 'class-c' | 'defensive-driving';
  experience: number | null;
  active: boolean | null;
  createdAt: Date;
}

const InstructorSchema = new Schema<InstructorDocument>({
  fullName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    trim: true,
    lowercase: true
  },
  phone: {
    type: String,
    required: true,
    trim: true
  },
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  specialization: {
    type: String,
    enum: ['class-a', 'class-b-manual', 'class-b-auto', 'class-c', 'defensive-driving'],
    required: true
  },
  experience: {
    type: Number,
    default: null
  },
  active: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create indexes
InstructorSchema.index({ userId: 1 }, { unique: true });
InstructorSchema.index({ email: 1 });
InstructorSchema.index({ phone: 1 });
InstructorSchema.index({ specialization: 1 });
InstructorSchema.index({ active: 1 });

// Create model and export
const InstructorModel = mongoose.models.Instructor || mongoose.model<InstructorDocument>('Instructor', InstructorSchema);

export default InstructorModel;