import mongoose, { Document, Schema } from 'mongoose';

export interface LessonDocument extends Document {
  studentId: number;
  instructorId: number;
  lessonNumber: number;
  date: Date;
  completed: boolean;
  notes: string | null;
  createdAt: Date;
}

const LessonSchema = new Schema<LessonDocument>({
  studentId: {
    type: Number,
    required: true
  },
  instructorId: {
    type: Number,
    required: true
  },
  lessonNumber: {
    type: Number,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  completed: {
    type: Boolean,
    default: false
  },
  notes: {
    type: String,
    default: null
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create indexes
LessonSchema.index({ studentId: 1, lessonNumber: 1 });
LessonSchema.index({ instructorId: 1 });
LessonSchema.index({ date: 1 });
LessonSchema.index({ completed: 1 });

// Create model and export
const LessonModel = mongoose.models.Lesson || mongoose.model<LessonDocument>('Lesson', LessonSchema);

export default LessonModel;