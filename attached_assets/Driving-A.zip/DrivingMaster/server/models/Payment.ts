import mongoose, { Document, Schema } from 'mongoose';

export interface PaymentDocument extends Document {
  studentId: number;
  amount: number;
  method: 'mpesa' | 'bank' | 'cash' | 'other';
  status: 'pending' | 'completed' | 'failed';
  transactionId: string | null;
  date: Date;
  metadata: any;
  receiptNumber: string | null;
  createdAt: Date;
}

const PaymentSchema = new Schema<PaymentDocument>({
  studentId: {
    type: Number,
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  method: {
    type: String,
    enum: ['mpesa', 'bank', 'cash', 'other'],
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed'],
    default: 'pending'
  },
  transactionId: {
    type: String,
    default: null
  },
  date: {
    type: Date,
    default: Date.now
  },
  metadata: {
    type: Schema.Types.Mixed,
    default: {}
  },
  receiptNumber: {
    type: String,
    default: null
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create indexes
PaymentSchema.index({ studentId: 1 });
PaymentSchema.index({ transactionId: 1 });
PaymentSchema.index({ status: 1 });
PaymentSchema.index({ method: 1 });
PaymentSchema.index({ date: -1 });
PaymentSchema.index({ createdAt: -1 });

// Create model and export
const PaymentModel = mongoose.models.Payment || mongoose.model<PaymentDocument>('Payment', PaymentSchema);

export default PaymentModel;