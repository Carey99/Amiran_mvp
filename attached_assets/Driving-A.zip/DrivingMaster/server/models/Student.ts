import mongoose, { Document, Schema } from 'mongoose';

export interface StudentDocument extends Document {
  fullName: string;
  email: string;
  phone: string;
  idNumber: string;
  address: string;
  courseType: 'class-a' | 'class-b-manual' | 'class-b-auto' | 'class-c' | 'defensive-driving';
  branch: 'kahawa-sukari' | 'mwihoko';
  status: 'active' | 'pending' | 'completed';
  instructorId: number | null;
  balance: number;
  totalLessons: number;
  lessonsCompleted: number;
  registrationDate: Date;
  comments: string | null;
  nextLessonDate: Date | null;
  createdAt: Date;
  courseFee: number;
}

const StudentSchema = new Schema<StudentDocument>({
  fullName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    trim: true,
    lowercase: true
  },
  phone: {
    type: String,
    required: true,
    trim: true
  },
  idNumber: {
    type: String,
    required: true,
    trim: true,
    unique: true
  },
  address: {
    type: String,
    required: true,
    trim: true
  },
  courseType: {
    type: String,
    enum: ['class-a', 'class-b-manual', 'class-b-auto', 'class-c', 'defensive-driving'],
    required: true
  },
  branch: {
    type: String,
    enum: ['kahawa-sukari', 'mwihoko'],
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'pending', 'completed'],
    default: 'pending'
  },
  instructorId: {
    type: Number,
    default: null
  },
  balance: {
    type: Number,
    required: true,
    default: 0
  },
  totalLessons: {
    type: Number,
    required: true,
    default: 0
  },
  lessonsCompleted: {
    type: Number,
    required: true,
    default: 0
  },
  registrationDate: {
    type: Date,
    default: Date.now
  },
  comments: {
    type: String,
    default: null
  },
  nextLessonDate: {
    type: Date,
    default: null
  },
  courseFee: {
    type: Number,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create indexes
StudentSchema.index({ idNumber: 1 }, { unique: true });
StudentSchema.index({ email: 1 });
StudentSchema.index({ phone: 1 });
StudentSchema.index({ status: 1 });
StudentSchema.index({ branch: 1 });
StudentSchema.index({ instructorId: 1 });
StudentSchema.index({ courseType: 1 });
StudentSchema.index({ registrationDate: -1 });

// Create model and export
const StudentModel = mongoose.models.Student || mongoose.model<StudentDocument>('Student', StudentSchema);

export default StudentModel;