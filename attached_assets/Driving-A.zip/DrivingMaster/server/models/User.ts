import mongoose, { Document, Schema } from 'mongoose';
import bcrypt from 'bcrypt';

export interface UserDocument extends Document {
  fullname: string;
  /**username: string; */
  password: string;
  email: string;
  phone: string | null;
  role: 'super_admin' | 'admin' | 'instructor';
  createdAt: Date;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

const UserSchema = new Schema<UserDocument>({
  fullname: {
    type: String,
    required: true,
    trim: true
  },
  /**username: {
    type: String,
    required: true,
    unique: true,
    trim: true
  }, */
  password: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  phone: {
    type: String,
    required: false,
    default: null
  },
  role: {
    type: String,
    enum: ['super_admin', 'admin', 'instructor'],
    required: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create indexes
UserSchema.index({ fullname: 1 }, { unique: true });
UserSchema.index({ email: 1 }, { unique: true });
UserSchema.index({ role: 1 });

// Password hashing middleware
UserSchema.pre('save', async function(next) {
  // Only hash the password if it's modified
  if (!this.isModified('password')) return next();

  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error: any) {
    next(error);
  }
});

// Method to compare passwords
UserSchema.methods.comparePassword = async function(candidatePassword: string): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.password);
};

// Create model and export
const UserModel = mongoose.models.User || mongoose.model<UserDocument>('User', UserSchema);

export default UserModel;