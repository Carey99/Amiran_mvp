import express, { type Express } from "express";
import cors from "cors";
import { createServer, METHODS, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import MemoryStore from "memorystore";
import { z } from "zod";
import { authMiddleware, checkRole } from "./middlewares/auth";


// Controllers
import * as authController from "./controllers/authController";
import * as studentController from "./controllers/studentController";
import * as instructorController from "./controllers/instructorController";
import * as dashboardController from "./controllers/dashboardController";
import * as paymentController from "./controllers/paymentController";
import * as lessonController from "./controllers/lessonController";
import { all } from "axios";

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  //allow CORS to allow frontend data
  app.use(
    cors({
      origin: "*", // allow all origins
      methods: ["GET", "POST", "PATCH", "DELETE"], // allow these methods
      allowedHeaders: ["Content-Type", "Authorization"], // allow these headers
    })
  );
  // Session setup
  const MemoryStoreSession = MemoryStore(session);
  app.use(
    session({
      store: new MemoryStoreSession({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
      secret: process.env.SESSION_SECRET || "amiran-driving-school-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 1 day --> for testing set to false (process.env.NODE_ENV === "production")
    })
  );

  // Student registration route (public)
  app.post("/api/students/register", (req: any, res: any, next: any) => {  
    console.log("📩 Received request to register student", req.body);  
    studentController.registerStudent(req, res);  
  });
  
  // Auth routes
  app.post("/api/auth/admin/signup", authController.adminSignup);
  //app.post("/api/auth/login", authController.login);
  //app.post("/api/auth/logout", authController.logout);
  //app.get("/api/auth/me", (req, res) => {
  //  res.status(200).json({ message: "Authentication bypassed", user: null });
  //});
  

  // Protected routes
  //app.use("/api", authMiddleware);

  // Dashboard routes
  //app.get("/api/dashboard/stats", checkRole(["admin", "super_admin"]), dashboardController.getStats);

  // Student routes (admin only)
  //app.get("/api/students/all", checkRole(["admin", "super_admin"]), studentController.getAllStudents);
  //app.get("/api/students/recent", checkRole(["admin", "super_admin"]), studentController.getRecentStudents);
  //app.get("/api/students/:id", checkRole(["admin", "super_admin"]), studentController.getStudentById);
  //app.patch("/api/students/:id/balance", checkRole(["super_admin"]), studentController.adjustStudentBalance);

  // Lesson routes
  //app.post("/api/students/:id/lessons", checkRole(["instructor", "admin", "super_admin"]), lessonController.addLesson);
  //app.get("/api/receipts/:lessonId", checkRole(["instructor", "admin", "super_admin"]), lessonController.generateReceipt);

  // Payment routes
  //app.post("/api/payments/mpesa", paymentController.initiatePayment);
  //app.get("/api/payments/recent", checkRole(["admin", "super_admin"]), paymentController.getRecentPayments);
  //app.get("/api/payments/callback", paymentController.handlePaymentCallback);
  //app.post("/api/payments/confirm/:transactionId", paymentController.confirmPayment);

  // Reports routes
  //app.get("/api/payments/reports", checkRole(["admin", "super_admin"]), paymentController.generateReport);

  // Error handler
  app.use((err: Error, req: any, res: any, next: any) => {
    console.error(err.stack);
    res.status(500).json({ message: "An unexpected error occurred" });
  });

  const httpServer = createServer(app);

  return httpServer;
}
