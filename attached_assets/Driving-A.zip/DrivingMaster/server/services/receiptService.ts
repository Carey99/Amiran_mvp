import { storage } from '../storage';
import { Student, Instructor, Lesson } from '@shared/schema';

/**
 * Generate a detailed receipt for a lesson
 * @param lessonId The ID of the lesson to generate a receipt for
 * @returns The receipt content as a string
 */
export async function generateLessonReceipt(lessonId: number): Promise<string> {
  try {
    // Get the lesson
    const lesson = await storage.getLessonById(lessonId);
    if (!lesson) {
      throw new Error('Lesson not found');
    }

    // Get the student
    const student = await storage.getStudentById(lesson.studentId);
    if (!student) {
      throw new Error('Student not found');
    }

    // Get the instructor
    const instructor = await storage.getInstructorById(lesson.instructorId);
    if (!instructor) {
      throw new Error('Instructor not found');
    }

    // Format the date
    const formattedDate = new Date(lesson.date).toLocaleDateString('en-KE', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    // Get completed lessons count
    const studentLessons = await storage.getLessonsByStudentId(student.id);
    const completedLessonsCount = studentLessons.filter(l => l.completed).length;

    // Generate receipt content
    const receiptContent = `
=============================================
            AMIRAN DRIVING SCHOOL
            Official Lesson Receipt
=============================================

Receipt Number: ALS-${lessonId}-${Date.now().toString().substring(7)}
Date: ${formattedDate}
Branch: ${formatBranch(student.branch)}

STUDENT INFORMATION
------------------
Name: ${student.fullName}
ID Number: ${student.idNumber}
Phone: ${student.phone}
Course: ${formatCourseType(student.courseType)}
Total Lessons: ${student.totalLessons}
Lessons Completed: ${completedLessonsCount}

LESSON INFORMATION
------------------
Lesson Number: ${lesson.lessonNumber} of ${student.totalLessons}
Instructor: ${instructor.fullName}
Status: ${lesson.completed ? 'Completed' : 'Pending'}
${lesson.notes ? `Notes: ${lesson.notes}` : ''}

PAYMENT STATUS
------------------
Total Course Fee: KES ${student.courseFee?.toLocaleString() || 'N/A'}
Current Balance: KES ${student.balance.toLocaleString()}
${student.balance <= 0 ? 'Status: Fully Paid' : 'Status: Payment Required'}

---------------------------------------------
Thank you for choosing Amiran Driving School.
For inquiries, call +254 712 345 678
---------------------------------------------
Generated on: ${new Date().toLocaleString()}
=============================================
    `;

    return receiptContent;
  } catch (error: any) {
    console.error('Receipt generation error:', error);
    throw new Error(`Failed to generate receipt: ${error.message}`);
  }
}

/**
 * Format course type for display
 */
function formatCourseType(courseType: string): string {
  switch (courseType) {
    case 'class-a':
      return 'Class A - Heavy Commercial';
    case 'class-b-manual':
      return 'Class B - Manual Transmission';
    case 'class-b-auto':
      return 'Class B - Automatic Transmission';
    case 'class-c':
      return 'Class C - Motorcycles';
    case 'defensive-driving':
      return 'Defensive Driving Course';
    default:
      return courseType;
  }
}

/**
 * Format payment method for display
 */
function formatPaymentMethod(method: string): string {
  switch (method) {
    case 'mpesa':
      return 'M-Pesa';
    case 'bank':
      return 'Bank Transfer';
    case 'cash':
      return 'Cash';
    case 'other':
      return 'Other';
    default:
      return method;
  }
}

/**
 * Format payment status for display
 */
function formatPaymentStatus(status: string): string {
  switch (status) {
    case 'pending':
      return 'Pending';
    case 'completed':
      return 'Completed';
    case 'failed':
      return 'Failed';
    default:
      return status;
  }
}

/**
 * Format branch for display
 */
function formatBranch(branch: string): string {
  switch (branch) {
    case 'kahawa-sukari':
      return 'Kahawa Sukari';
    case 'mwihoko':
      return 'Mwihoko';
    default:
      return branch;
  }
}