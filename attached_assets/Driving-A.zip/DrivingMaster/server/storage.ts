import {
  users, type User, type InsertUser,
  students, type Student, type InsertStudent,
  instructors, type Instructor, type InsertInstructor,
  lessons, type Lesson, type InsertLesson,
  payments, type Payment, type InsertPayment
} from "@shared/schema";
import { hashPassword, comparePassword } from "./utils/passwordUtils";

// modify the interface with any CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  validateUserCredentials(username: string, password: string): Promise<User | null>;

  // Student methods
  getAllStudents(): Promise<Student[]>;
  getCurrentStudents(): Promise<Student[]>;
  getConcludedStudents(): Promise<Student[]>;
  getRecentStudents(limit?: number): Promise<Student[]>;
  getStudentById(id: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudentBalance(id: number, adjustment: number): Promise<Student | undefined>;
  getStudentsByInstructorId(instructorId: number): Promise<Student[]>;

  // Instructor methods
  getAllInstructors(): Promise<Instructor[]>;
  getInstructorById(id: number): Promise<Instructor | undefined>;
  getInstructorByUserId(userId: number): Promise<Instructor | undefined>;
  createInstructor(instructor: InsertInstructor): Promise<Instructor>;

  // Lesson methods
  getLessonById(id: number): Promise<Lesson | undefined>;
  getLessonsByStudentId(studentId: number): Promise<Lesson[]>;
  getRecentLessonsByInstructorId(instructorId: number): Promise<Lesson[]>;
  getUpcomingLessonsByInstructorId(instructorId: number): Promise<Lesson[]>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  getTotalLessonsCompletedToday(): Promise<number>;

  // Payment methods
  getPaymentById(id: number): Promise<Payment | undefined>;
  getPaymentsByStudentId(studentId: number): Promise<Payment[]>;
  getAllPayments(): Promise<Payment[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePaymentStatus(id: number, status: string, transactionId?: string): Promise<Payment | undefined>;
  getRecentPayments(limit?: number): Promise<Payment[]>;
  getTodayTotalPayments(): Promise<number>;
  
  // Stats methods
  getTotalStudentsCount(): Promise<number>;
  getCurrentStudentsCount(): Promise<number>;
  getMonthlyRevenue(): Promise<number>;
  getPendingPaymentsTotal(): Promise<number>;
  getTodayRegistrationsCount(): Promise<number>;
  getPaymentRemindersCount(): Promise<number>;
}

export class MemStorage implements IStorage {
  private _users: Map<number, User>;
  private _students: Map<number, Student>;
  private _instructors: Map<number, Instructor>;
  private _lessons: Map<number, Lesson>;
  private _payments: Map<number, Payment>;
  private _userIdCounter: number;
  private _studentIdCounter: number;
  private _instructorIdCounter: number;
  private _lessonIdCounter: number;
  private _paymentIdCounter: number;

  constructor() {
    this._users = new Map();
    this._students = new Map();
    this._instructors = new Map();
    this._lessons = new Map();
    this._payments = new Map();
    this._userIdCounter = 1;
    this._studentIdCounter = 1;
    this._instructorIdCounter = 1;
    this._lessonIdCounter = 1;
    this._paymentIdCounter = 1;

    // Create initial admin user
    this._createInitialData();
  }

  private async _createInitialData() {
    // Create superadmin
    const superAdminUser: InsertUser = {
      username: "superadmin",
      password: await hashPassword("superadmin123"),
      name: "Super Admin",
      email: "superadmin@amiran.com",
      phone: "+254712345678",
      role: "super_admin"
    };
    const superAdmin = await this.createUser(superAdminUser);

    // Create regular admin
    const adminUser: InsertUser = {
      username: "admin",
      password: await hashPassword("admin123"),
      name: "Regular Admin",
      email: "admin@amiran.com",
      phone: "+254723456789",
      role: "admin"
    };
    const admin = await this.createUser(adminUser);

    // Create instructor
    const instructorUser: InsertUser = {
      username: "instructor",
      password: await hashPassword("instructor123"),
      name: "John Instructor",
      email: "instructor@amiran.com",
      phone: "+254734567890",
      role: "instructor"
    };
    const instructor = await this.createUser(instructorUser);

    // Create instructor profile
    const instructorProfile: InsertInstructor = {
      userId: instructor.id,
      fullName: "John Instructor",
      email: "instructor@amiran.com",
      phone: "+254734567890",
      specialization: "class-b-manual",
      experience: 5,
      active: true
    };
    const instructorEntity = await this.createInstructor(instructorProfile);

    // Create sample students
    const student1: InsertStudent = {
      fullName: "Jane Mwangi",
      email: "jane.m@example.com",
      phone: "+254712345678",
      address: "123 Nairobi Way",
      idNumber: "12345678",
      courseType: "class-b-manual",
      branch: "kahawa-sukari",
      status: "active",
      balance: 15000,
      courseFee: 30000,
      totalLessons: 20,
      comments: "Interested in intensive training"
    };
    const student1Entity = await this.createStudent(student1);

    const student2: InsertStudent = {
      fullName: "Peter Kamau",
      email: "peter.k@example.com",
      phone: "+254723456789",
      address: "456 Mombasa Road",
      idNumber: "23456789",
      courseType: "class-b-auto",
      branch: "mwihoko",
      status: "active",
      balance: 8000,
      courseFee: 25000,
      totalLessons: 15,
      comments: "Weekend classes preferred"
    };
    const student2Entity = await this.createStudent(student2);

    const student3: InsertStudent = {
      fullName: "Sarah Mutua",
      email: "sarah.m@example.com",
      phone: "+254734567890",
      address: "789 Kisumu Street",
      idNumber: "34567890",
      courseType: "class-a",
      branch: "kahawa-sukari",
      status: "pending",
      balance: 22000,
      courseFee: 22000,
      totalLessons: 12,
      comments: "Wants to complete in one month"
    };
    await this.createStudent(student3);

    // Create some lessons
    const lesson1: InsertLesson = {
      studentId: student1Entity.id,
      instructorId: instructorEntity.id,
      lessonNumber: 1,
      notes: "Good progress with basic controls",
      completed: true
    };
    await this.createLesson(lesson1);

    const lesson2: InsertLesson = {
      studentId: student1Entity.id,
      instructorId: instructorEntity.id,
      lessonNumber: 2,
      notes: "Practiced parallel parking",
      completed: true
    };
    await this.createLesson(lesson2);

    const lesson3: InsertLesson = {
      studentId: student2Entity.id,
      instructorId: instructorEntity.id,
      lessonNumber: 1,
      notes: "Introduction to vehicle controls",
      completed: true
    };
    await this.createLesson(lesson3);

    // Create some payments
    const payment1: InsertPayment = {
      studentId: student1Entity.id,
      amount: 15000,
      transactionId: "TXN-543921",
      method: "mpesa",
      status: "completed",
      date: new Date()
    };
    await this.createPayment(payment1);

    const payment2: InsertPayment = {
      studentId: student2Entity.id,
      amount: 17000,
      transactionId: "TXN-543842",
      method: "mpesa",
      status: "completed",
      date: new Date()
    };
    await this.createPayment(payment2);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this._users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this._users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this._userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this._users.set(id, user);
    return user;
  }

  async validateUserCredentials(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const isValid = await comparePassword(password, user.password);
    return isValid ? user : null;
  }

  // Student methods
  async getAllStudents(): Promise<Student[]> {
    return Array.from(this._students.values());
  }

  async getCurrentStudents(): Promise<Student[]> {
    return Array.from(this._students.values()).filter(student => 
      student.status === "active" || (student.status === "pending" && student.balance > 0)
    );
  }

  async getConcludedStudents(): Promise<Student[]> {
    return Array.from(this._students.values()).filter(student => 
      student.status === "completed"
    );
  }

  async getRecentStudents(limit: number = 5): Promise<Student[]> {
    return Array.from(this._students.values())
      .sort((a, b) => new Date(b.registrationDate).getTime() - new Date(a.registrationDate).getTime())
      .slice(0, limit);
  }

  async getStudentById(id: number): Promise<Student | undefined> {
    return this._students.get(id);
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = this._studentIdCounter++;
    const now = new Date();
    const student: Student = { 
      ...insertStudent, 
      id, 
      registrationDate: now, 
      createdAt: now
    };
    this._students.set(id, student);
    return student;
  }

  async updateStudentBalance(id: number, adjustment: number): Promise<Student | undefined> {
    const student = await this.getStudentById(id);
    if (!student) return undefined;

    // Calculate new balance, ensure it doesn't go below 0
    const newBalance = Math.max(0, student.balance + adjustment);
    
    // Update student
    const updatedStudent = { ...student, balance: newBalance };
    this._students.set(id, updatedStudent);
    
    return updatedStudent;
  }

  async getStudentsByInstructorId(instructorId: number): Promise<Student[]> {
    // In a real database, we would have a relationship between instructors and students
    // For this implementation, we'll assume all students are accessible to all instructors
    return this.getCurrentStudents();
  }

  // Instructor methods
  async getAllInstructors(): Promise<Instructor[]> {
    return Array.from(this._instructors.values());
  }

  async getInstructorById(id: number): Promise<Instructor | undefined> {
    return this._instructors.get(id);
  }

  async getInstructorByUserId(userId: number): Promise<Instructor | undefined> {
    return Array.from(this._instructors.values()).find(instructor => instructor.userId === userId);
  }

  async createInstructor(insertInstructor: InsertInstructor): Promise<Instructor> {
    const id = this._instructorIdCounter++;
    const now = new Date();
    const instructor: Instructor = { ...insertInstructor, id, createdAt: now, active: true };
    this._instructors.set(id, instructor);
    return instructor;
  }

  // Lesson methods
  async getLessonById(id: number): Promise<Lesson | undefined> {
    return this._lessons.get(id);
  }

  async getLessonsByStudentId(studentId: number): Promise<Lesson[]> {
    return Array.from(this._lessons.values())
      .filter(lesson => lesson.studentId === studentId)
      .sort((a, b) => a.lessonNumber - b.lessonNumber);
  }

  async getRecentLessonsByInstructorId(instructorId: number): Promise<Lesson[]> {
    return Array.from(this._lessons.values())
      .filter(lesson => lesson.instructorId === instructorId && lesson.completed)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 10);
  }

  async getUpcomingLessonsByInstructorId(instructorId: number): Promise<Lesson[]> {
    const today = new Date();
    // In a real system, there would be future scheduled lessons
    // For this mock, we'll pretend any lesson is upcoming
    return Array.from(this._lessons.values())
      .filter(lesson => lesson.instructorId === instructorId)
      .slice(0, 5);
  }

  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const id = this._lessonIdCounter++;
    const now = new Date();
    const lesson: Lesson = { ...insertLesson, id, date: now, createdAt: now };
    this._lessons.set(id, lesson);
    return lesson;
  }

  async getTotalLessonsCompletedToday(): Promise<number> {
    const today = new Date().toDateString();
    return Array.from(this._lessons.values())
      .filter(lesson => new Date(lesson.date).toDateString() === today && lesson.completed)
      .length;
  }

  // Payment methods
  async getPaymentById(id: number): Promise<Payment | undefined> {
    return this._payments.get(id);
  }

  async getPaymentsByStudentId(studentId: number): Promise<Payment[]> {
    return Array.from(this._payments.values())
      .filter(payment => payment.studentId === studentId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async getAllPayments(): Promise<Payment[]> {
    return Array.from(this._payments.values());
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this._paymentIdCounter++;
    const now = new Date();
    const payment: Payment = { ...insertPayment, id, createdAt: now };
    this._payments.set(id, payment);
    return payment;
  }

  async updatePaymentStatus(id: number, status: string, transactionId?: string): Promise<Payment | undefined> {
    const payment = await this.getPaymentById(id);
    if (!payment) return undefined;
    
    const updatedPayment = { 
      ...payment, 
      status: status as any, 
      ...(transactionId && { transactionId })
    };
    
    this._payments.set(id, updatedPayment);
    return updatedPayment;
  }

  async getRecentPayments(limit: number = 5): Promise<Payment[]> {
    return Array.from(this._payments.values())
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, limit);
  }

  async getTodayTotalPayments(): Promise<number> {
    const today = new Date().toDateString();
    return Array.from(this._payments.values())
      .filter(payment => 
        new Date(payment.date).toDateString() === today && 
        payment.status === 'completed'
      )
      .reduce((sum, payment) => sum + payment.amount, 0);
  }

  // Stats methods
  async getTotalStudentsCount(): Promise<number> {
    return this._students.size;
  }

  async getCurrentStudentsCount(): Promise<number> {
    return (await this.getCurrentStudents()).length;
  }

  async getMonthlyRevenue(): Promise<number> {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    return Array.from(this._payments.values())
      .filter(payment => 
        new Date(payment.date) >= monthStart && 
        payment.status === 'completed'
      )
      .reduce((sum, payment) => sum + payment.amount, 0);
  }

  async getPendingPaymentsTotal(): Promise<number> {
    return Array.from(this._students.values())
      .reduce((sum, student) => sum + student.balance, 0);
  }

  async getTodayRegistrationsCount(): Promise<number> {
    const today = new Date().toDateString();
    return Array.from(this._students.values())
      .filter(student => new Date(student.registrationDate).toDateString() === today)
      .length;
  }

  async getPaymentRemindersCount(): Promise<number> {
    // In a real system, this would be the count of reminders sent
    // For this mock, we'll count students with a balance who haven't made a payment in the last 7 days
    return 3; // Mocked value
  }
}

// Import MongoDB storage
import { MongoStorage } from './db/mongoStorage';

// Always use MongoDB storage as requested by the user
export const storage = new MongoStorage();
