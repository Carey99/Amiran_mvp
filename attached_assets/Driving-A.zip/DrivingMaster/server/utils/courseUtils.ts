
export const calculateTotalFee = (courseType: string): number => {
  switch (courseType) {
    case 'class-a':
      return 15000;
    case 'class-b-manual':
      return 30000;
    case 'class-b-auto':
      return 25000;
    case 'class-c':
      return 40000;
    case 'defensive-driving':
      return 10000;
    default:
      return 0;
  }
};

export const getLessonCount = (courseType: string): number => {
  switch (courseType) {
    case 'class-a':
      return 10;
    case 'class-b-manual':
      return 20;
    case 'class-b-auto':
      return 15;
    case 'class-c':
      return 25;
    case 'defensive-driving':
      return 5;
    default:
      return 0;
  }
};

export const formatCourseType = (courseType: string): string => {
  switch (courseType) {
    case 'class-a':
      return 'Class A (Motorcycle)';
    case 'class-b-manual':
      return 'Class B (Manual)';
    case 'class-b-auto':
      return 'Class B (Automatic)';
    case 'class-c':
      return 'Class C (Commercial)';
    case 'defensive-driving':
      return 'Defensive Driving';
    default:
      return courseType;
  }
};

export const formatBranch = (branch: string): string => {
  switch (branch) {
    case 'kahawa-sukari':
      return 'Kahawa Sukari';
    case 'mwihoko':
      return 'Mwihoko';
    default:
      return branch;
  }
};
