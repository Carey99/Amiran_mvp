
import { z } from "zod";

// User schemas
export const UserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(["admin", "super_admin"]),
  name: z.string(),
});

export const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

// Student schemas
export const insertStudentSchema = z.object({
  fullName: z.string(),
  email: z.string().email(),
  phone: z.string(),
  address: z.string(),
  idNumber: z.string(),
  courseType: z.enum(["class-a", "class-b-manual", "class-b-auto", "class-c", "defensive-driving"]),
  branch: z.enum(["kahawa-sukari", "mwihoko"]),
  status: z.enum(["active", "pending", "completed", "suspended"]).default("pending"),
  balance: z.number().optional(),
  courseFee: z.number().optional(),
  totalLessons: z.number().optional(),
  comments: z.string().optional(),
});

// Instructor schemas
export const insertInstructorSchema = z.object({
  fullName: z.string(),
  email: z.string().email(),
  phone: z.string(),
  userId: z.string(),
  specialization: z.enum(["class-a", "class-b-manual", "class-b-auto", "class-c", "defensive-driving"]),
  experience: z.number().nullable(),
  active: z.boolean().default(true),
});

// Lesson schemas
export const insertLessonSchema = z.object({
  studentId: z.number(),
  instructorId: z.number(),
  lessonNumber: z.number(),
  notes: z.string(),
  completed: z.boolean().default(false),
  date: z.date().optional(),
});

// Payment schemas
export const insertPaymentSchema = z.object({
  studentId: z.number(),
  amount: z.number(),
  transactionId: z.string().optional(),
  method: z.enum(["mpesa", "cash", "bank"]),
  status: z.enum(["pending", "completed", "failed"]).default("pending"),
  date: z.date().optional(),
});

// Export types
export type User = z.infer<typeof UserSchema>;
export type Login = z.infer<typeof LoginSchema>;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type InsertInstructor = z.infer<typeof insertInstructorSchema>;
export type InsertLesson = z.infer<typeof insertLessonSchema>;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
